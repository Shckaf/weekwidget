package com.example.weekwidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.ZoneId

val DAY_NAMES = listOf("Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье")

object ScheduleStore {
    private const val FILE = "schedule"
    private fun p(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    /** num = над чертой, dow = 1 (пн) .. 7 (вс) */
    fun key(num: Boolean, dow: Int) = "${if (num) "num" else "den"}.$dow"

    fun getDay(ctx: Context, num: Boolean, dow: Int): String =
        p(ctx).getString(key(num, dow), "") ?: ""

    // Если «какая неделя сейчас» не задана здесь — берём из настроек виджета «Неделя».
    fun anchorMonday(ctx: Context): LocalDate =
        p(ctx).getString("anchor", null)?.let { LocalDate.parse(it) } ?: ConfigStore.loadForUi(ctx).anchorMonday

    fun anchorNumerator(ctx: Context): Boolean =
        if (p(ctx).contains("anchorNum")) p(ctx).getBoolean("anchorNum", false)
        else ConfigStore.loadForUi(ctx).anchorNumerator

    fun bg(ctx: Context): Int = p(ctx).getInt("bg", 0xFF212529.toInt())

    fun isNumeratorToday(ctx: Context): Boolean =
        WeekLogic.isNumerator(LocalDate.now(), anchorMonday(ctx), anchorNumerator(ctx))

    fun save(ctx: Context, days: Map<String, String>, anchorMonday: LocalDate, anchorNum: Boolean, bg: Int) {
        val e = p(ctx).edit()
        days.forEach { (k, v) -> e.putString(k, v) }
        e.putString("anchor", anchorMonday.toString())
        e.putBoolean("anchorNum", anchorNum)
        e.putInt("bg", bg)
        e.apply()
    }
}

class ScheduleWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(ctx, mgr, it) }
        scheduleMidnight(ctx)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        when (intent.action) {
            ACTION_MIDNIGHT,
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED -> updateAll(ctx)
        }
    }

    override fun onDisabled(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java).cancel(midnightIntent(ctx))
    }

    companion object {
        private const val ACTION_MIDNIGHT = "com.example.weekwidget.SCHEDULE_MIDNIGHT"

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, ScheduleWidgetProvider::class.java))
            ids.forEach { update(ctx, mgr, it) }
            scheduleMidnight(ctx)
        }

        fun update(ctx: Context, mgr: AppWidgetManager, id: Int) {
            val today = LocalDate.now()
            val num = ScheduleStore.isNumeratorToday(ctx)
            val dow = today.dayOfWeek.value
            val lines = ScheduleStore.getDay(ctx, num, dow)
                .lines().map { it.trim() }.filter { it.isNotEmpty() }

            val bg = ScheduleStore.bg(ctx)
            val fg = if (isLight(bg)) Color.BLACK else Color.WHITE

            val rv = RemoteViews(ctx.packageName, R.layout.widget_schedule)
            rv.setInt(R.id.bg, "setColorFilter", bg)
            rv.setTextViewText(R.id.head, "${DAY_NAMES[dow - 1]} · ${if (num) "над чертой" else "под чертой"}")
            rv.setTextViewText(R.id.body, if (lines.isEmpty()) "Занятий нет" else lines.joinToString("\n"))
            rv.setTextColor(R.id.head, fg)
            rv.setTextColor(R.id.body, fg)

            val open = Intent(ctx, ScheduleActivity::class.java)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            val pi = PendingIntent.getActivity(
                ctx, id + 100000, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            rv.setOnClickPendingIntent(R.id.root, pi)

            mgr.updateAppWidget(id, rv)
        }

        private fun isLight(c: Int): Boolean =
            (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255 > 0.6

        private fun midnightIntent(ctx: Context): PendingIntent {
            val i = Intent(ctx, ScheduleWidgetProvider::class.java).setAction(ACTION_MIDNIGHT)
            return PendingIntent.getBroadcast(
                ctx, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private fun scheduleMidnight(ctx: Context) {
            val next = LocalDate.now().plusDays(1)
                .atStartOfDay(ZoneId.systemDefault()).plusSeconds(5)
                .toInstant().toEpochMilli()
            ctx.getSystemService(AlarmManager::class.java)
                .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, midnightIntent(ctx))
        }
    }
}
