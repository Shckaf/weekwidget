package com.example.weekwidget

/** Одна пара в расписании. Обычный класс (не data), чтобы сравнивать по ссылке. */
class Lesson(var time: String, var title: String)

/**
 * Разбор и форматирование строк расписания.
 * В хранилище пары лежат обычным текстом, по строке на пару: «09:00 Математика, ауд. 305».
 * Поэтому виджет читает те же данные, что и редактор.
 */
object Lessons {
    /** Типичная сетка звонков: подставляется как время следующей пары. */
    val BELLS = listOf("08:30", "10:10", "11:50", "13:50", "15:30", "17:10", "18:50")

    // «9», «9:00», «9.00», «9:00-10:30», «9-10»; после времени — пробел или конец строки.
    private val TIME_LINE = Regex("""^\s*(\d{1,2})(?:[:.](\d{2}))?(?:\s*[-–—]\s*(\d{1,2})(?:[:.](\d{2}))?)?(?=\s|$)\s*(.*)$""")

    // «Математика 305», «Математика ауд 305», «Математика, к. 305» -> «Математика, ауд. 305»
    private val ROOM = Regex("""^(.*?\S)[\s,]+(?:(?:ауд|каб|к)\.?\s*)?(\d{3,4}[а-яa-z]?)$""", RegexOption.IGNORE_CASE)

    private val START = Regex("""^(\d{2}):(\d{2})""")

    fun parseLine(raw: String): Lesson? {
        val line = raw.trim()
        if (line.isEmpty()) return null

        var time = ""
        var title = line
        val m = TIME_LINE.matchEntire(line)
        if (m != null) {
            val h = m.groupValues[1].toInt()
            val mi = m.groupValues[2].ifEmpty { "0" }.toInt()
            val h2 = m.groupValues[3]
            val mi2 = m.groupValues[4].ifEmpty { "0" }.toInt()
            val endOk = h2.isEmpty() || (h2.toInt() in 0..23 && mi2 in 0..59)
            if (h in 0..23 && mi in 0..59 && endOk) {
                time = fmt(h, mi)
                if (h2.isNotEmpty()) time += "–" + fmt(h2.toInt(), mi2)
                title = m.groupValues[5]
            }
        }
        return Lesson(time, normalizeTitle(title))
    }

    fun normalizeTitle(raw: String): String {
        var t = raw.trim().replace(Regex("""\s+"""), " ")
        if (t.isEmpty()) return t
        val m = ROOM.matchEntire(t)
        if (m != null) t = m.groupValues[1].trimEnd(',', ' ') + ", ауд. " + m.groupValues[2]
        return t.replaceFirstChar { it.uppercase() }
    }

    /** «Математика, ауд. 305» -> «Математика» (для подсказок). */
    fun baseTitle(t: String): String = t.replace(Regex(""",\s*ауд\.\s*\S+$"""), "")

    fun format(l: Lesson): String =
        listOf(l.time, l.title).filter { it.isNotBlank() }.joinToString(" ")

    fun toText(list: List<Lesson>): String =
        list.filter { it.time.isNotBlank() || it.title.isNotBlank() }
            .sortedBy { sortKey(it.time) }
            .joinToString("\n") { format(it) }

    fun fromText(text: String): MutableList<Lesson> =
        text.lines().mapNotNull { parseLine(it) }.toMutableList()

    /** Пары без времени идут в конце. */
    fun sortKey(time: String): String = if (time.isBlank()) "99:99" else time.take(5)

    fun startOf(time: String): Pair<Int, Int>? {
        val m = START.find(time) ?: return null
        return m.groupValues[1].toInt() to m.groupValues[2].toInt()
    }

    /** Время следующей пары: ближайший звонок после предыдущей пары. */
    fun nextSlot(prev: String?): String {
        val s = prev?.let { startOf(it) } ?: return BELLS.first()
        val prevMin = s.first * 60 + s.second
        for (b in BELLS) {
            val (h, m) = startOf(b)!!
            if (h * 60 + m > prevMin) return b
        }
        val next = prevMin + 100
        return fmt((next / 60) % 24, next % 60)
    }

    private fun fmt(h: Int, m: Int): String = String.format("%02d:%02d", h, m)
}
