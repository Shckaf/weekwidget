package com.example.weekwidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.Toast
import java.time.LocalDate

/**
 * Настройки виджета «Неделя». Открывается:
 *  - с главного экрана приложения (widgetId = 0: настройки применяются ко всем виджетам «Неделя»);
 *  - при добавлении виджета на экран и по тапу на него (настройки именно этого виджета).
 */
class ConfigActivity : Activity() {

    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private val standalone: Boolean get() = widgetId == AppWidgetManager.INVALID_APPWIDGET_ID

    private var numColor = 0
    private var denColor = 0
    private var currentIsNum = false

    private lateinit var numEdit: EditText
    private lateinit var denEdit: EditText
    private lateinit var datesSwitch: Switch
    private lateinit var preview: FrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        widgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        // Если выйти без сохранения при добавлении виджета — виджет не добавится.
        setResult(RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))

        val cfg = if (standalone) ConfigStore.loadForUi(this) else ConfigStore.load(this, widgetId)
        numColor = cfg.numColor
        denColor = cfg.denColor
        currentIsNum = cfg.isNumerator()

        val col = column()

        // --- Предпросмотр ---
        preview = FrameLayout(this)
        col.addView(preview, lp(h = dp(130)))

        // --- Какая неделя сейчас ---
        val c1 = cardBox()
        c1.addView(sectionTitle("Какая неделя сейчас"))
        c1.addView(tv(weekRangeText(), 14f, Ui.MUTED), lp(top = 2))
        c1.addView(
            segmented(listOf("Над чертой", "Под чертой"), if (currentIsNum) 0 else 1) {
                currentIsNum = it == 0
                render()
            },
            lp(top = 10)
        )
        col.addView(c1, lp(top = 12))

        // --- Подписи и цвета ---
        numEdit = input("Над чертой", cfg.numLabel).apply { onChanged { render() } }
        col.addView(
            labelCard("Неделя «над чертой»", numEdit, { numColor }) { numColor = it; render() },
            lp(top = 12)
        )
        denEdit = input("Под чертой", cfg.denLabel).apply { onChanged { render() } }
        col.addView(
            labelCard("Неделя «под чертой»", denEdit, { denColor }) { denColor = it; render() },
            lp(top = 12)
        )

        // --- Даты ---
        val c4 = cardBox()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(tv("Показывать даты недели", 15f), lp(w = 0, weight = 1f))
        datesSwitch = Switch(this).apply {
            isChecked = cfg.showDates
            setOnCheckedChangeListener { _, _ -> render() }
        }
        row.addView(datesSwitch, lp(WRAP, WRAP))
        c4.addView(row)
        col.addView(c4, lp(top = 12))

        val header = if (standalone) {
            tabsHeader(0, onBack = { persist(); finish() }, onSwitch = { persist(); switchTab(it) })
        } else titleHeader("Виджет «Неделя»")

        setContentView(screen(header, col, bottomBar("Сохранить") { saveAndClose() }))
        render()
    }

    override fun onBackPressed() {
        if (standalone) persist()
        super.onBackPressed()
    }

    private fun labelCard(
        title: String,
        edit: EditText,
        current: () -> Int,
        onPick: (Int) -> Unit,
    ): LinearLayout {
        val card = cardBox()
        card.addView(sectionTitle(title))
        card.addView(edit, lp(top = 10))
        card.addView(swatches(Ui.PALETTE, current, onPick), lp(top = 4))
        return card
    }

    private fun render() {
        val num = currentIsNum
        val bg = if (num) numColor else denColor
        val fg = Ui.contrast(bg)
        val label = (if (num) numEdit.text else denEdit.text).toString()
            .ifBlank { if (num) "Над чертой" else "Под чертой" }

        preview.removeAllViews()
        preview.background = shape(bg, 16)
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        inner.addView(tv("Сейчас неделя", 12f, fg))
        inner.addView(tv(label, 26f, fg, true))
        if (datesSwitch.isChecked) inner.addView(tv(weekRangeText(), 13f, fg))
        preview.addView(inner, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun config() = WidgetConfig(
        anchorMonday = WeekLogic.mondayOf(LocalDate.now()),
        anchorNumerator = currentIsNum,
        numLabel = numEdit.text.toString().ifBlank { "Над чертой" },
        denLabel = denEdit.text.toString().ifBlank { "Под чертой" },
        numColor = numColor,
        denColor = denColor,
        showDates = datesSwitch.isChecked,
    )

    private fun persist() {
        if (standalone) ConfigStore.saveForUi(this, config()) else ConfigStore.save(this, widgetId, config())
        WeekWidgetProvider.updateAll(this)
    }

    private fun saveAndClose() {
        persist()
        if (standalone) {
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
        } else {
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        }
        finish()
    }
}
