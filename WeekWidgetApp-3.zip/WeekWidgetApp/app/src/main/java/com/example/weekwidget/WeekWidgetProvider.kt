package com.example.weekwidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

class WeekWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(ctx, mgr, it) }
        scheduleMidnight(ctx)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        when (intent.action) {
            ACTION_MIDNIGHT,
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED -> updateAll(ctx)
        }
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        ids.forEach { ConfigStore.delete(ctx, it) }
    }

    override fun onDisabled(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java).cancel(midnightIntent(ctx))
    }

    companion object {
        private const val ACTION_MIDNIGHT = "com.example.weekwidget.MIDNIGHT"

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, WeekWidgetProvider::class.java))
            ids.forEach { update(ctx, mgr, it) }
            scheduleMidnight(ctx)
        }

        fun update(ctx: Context, mgr: AppWidgetManager, id: Int) {
            val cfg = ConfigStore.load(ctx, id)
            val today = LocalDate.now()
            val num = cfg.isNumerator(today)
            val bg = if (num) cfg.numColor else cfg.denColor
            val fg = if (isLight(bg)) Color.BLACK else Color.WHITE

            val rv = RemoteViews(ctx.packageName, R.layout.widget_week)
            rv.setInt(R.id.bg, "setColorFilter", bg)
            rv.setTextViewText(R.id.title, if (num) cfg.numLabel else cfg.denLabel)
            rv.setTextColor(R.id.title, fg)
            rv.setTextColor(R.id.caption, fg)
            rv.setTextColor(R.id.sub, fg)

            if (cfg.showDates) {
                val monday = WeekLogic.mondayOf(today)
                val f = DateTimeFormatter.ofPattern("d MMM", Locale.forLanguageTag("ru"))
                rv.setTextViewText(R.id.sub, "${f.format(monday)} – ${f.format(monday.plusDays(6))}")
                rv.setViewVisibility(R.id.sub, View.VISIBLE)
            } else {
                rv.setViewVisibility(R.id.sub, View.GONE)
            }

            // Тап по виджету открывает его настройки.
            val open = Intent(ctx, ConfigActivity::class.java)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            val pi = PendingIntent.getActivity(
                ctx, id, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            rv.setOnClickPendingIntent(R.id.root, pi)

            mgr.updateAppWidget(id, rv)
        }

        private fun isLight(c: Int): Boolean {
            val lum = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255
            return lum > 0.6
        }

        private fun midnightIntent(ctx: Context): PendingIntent {
            val i = Intent(ctx, WeekWidgetProvider::class.java).setAction(ACTION_MIDNIGHT)
            return PendingIntent.getBroadcast(
                ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private fun scheduleMidnight(ctx: Context) {
            val next = LocalDate.now().plusDays(1)
                .atStartOfDay(ZoneId.systemDefault()).plusSeconds(5)
                .toInstant().toEpochMilli()
            ctx.getSystemService(AlarmManager::class.java)
                .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, midnightIntent(ctx))
        }
    }
}
