package com.example.weekwidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Экран настроек. Открывается:
 *  - с иконки приложения (id = 0 → настройки по умолчанию);
 *  - при добавлении виджета на экран (id виджета);
 *  - при тапе по виджету.
 */
class ConfigActivity : Activity() {

    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private var numColor = 0
    private var denColor = 0
    private var currentIsNum = false

    private lateinit var numEdit: EditText
    private lateinit var denEdit: EditText
    private lateinit var showDates: CheckBox
    private lateinit var pvCard: LinearLayout
    private lateinit var pvCaption: TextView
    private lateinit var pvTitle: TextView
    private lateinit var pvSub: TextView

    private val palette = listOf(
        0xFF1E66F5.toInt(), 0xFFE8590C.toInt(), 0xFF2F9E44.toInt(), 0xFF7048E8.toInt(),
        0xFFE03131.toInt(), 0xFF343A40.toInt(), 0xFF0C8599.toInt(), 0xFFD6336C.toInt(),
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        widgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        // Если пользователь выйдет без сохранения — виджет не добавится.
        setResult(RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))

        val cfg = ConfigStore.load(this, widgetId)
        numColor = cfg.numColor
        denColor = cfg.denColor
        currentIsNum = cfg.isNumerator()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }

        root.addView(
            text("by POTAPOV ILYA group EM <3", 13f, bold = true).apply {
                setTextColor(0xFF1E66F5.toInt())
                gravity = Gravity.CENTER
            },
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
        )
        root.addView(text("Виджет недели", 24f, bold = true))
        root.addView(text("Показывает, какая сейчас неделя: над чертой или под чертой.", 14f).pad(top = 4))

        // --- Предпросмотр ---
        root.addView(sectionTitle("Предпросмотр"))
        pvCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        pvCaption = text("Сейчас неделя", 12f)
        pvTitle = text("", 26f, bold = true)
        pvSub = text("", 13f)
        listOf(pvCaption, pvTitle, pvSub).forEach { pvCard.addView(it) }
        root.addView(pvCard, LinearLayout.LayoutParams(-1, dp(110)))

        // --- Какая неделя сейчас ---
        val monday = WeekLogic.mondayOf(LocalDate.now())
        val f = DateTimeFormatter.ofPattern("d MMM", Locale.forLanguageTag("ru"))
        root.addView(sectionTitle("Какая неделя сейчас? (${f.format(monday)} – ${f.format(monday.plusDays(6))})"))
        val group = RadioGroup(this)
        val rbNum = RadioButton(this).apply { text = "Над чертой (числитель)"; id = View.generateViewId() }
        val rbDen = RadioButton(this).apply { text = "Под чертой (знаменатель)"; id = View.generateViewId() }
        group.addView(rbNum)
        group.addView(rbDen)
        group.check(if (currentIsNum) rbNum.id else rbDen.id)
        group.setOnCheckedChangeListener { _, checked ->
            currentIsNum = checked == rbNum.id
            render()
        }
        root.addView(group)

        // --- Подписи ---
        root.addView(sectionTitle("Подпись для недели «над чертой»"))
        numEdit = EditText(this).apply { setText(cfg.numLabel); setSingleLine() }
        root.addView(numEdit)
        root.addView(swatches({ numColor }) { numColor = it; render() })

        root.addView(sectionTitle("Подпись для недели «под чертой»"))
        denEdit = EditText(this).apply { setText(cfg.denLabel); setSingleLine() }
        root.addView(denEdit)
        root.addView(swatches({ denColor }) { denColor = it; render() })

        showDates = CheckBox(this).apply {
            text = "Показывать даты недели"
            isChecked = cfg.showDates
            setOnCheckedChangeListener { _, _ -> render() }
        }
        root.addView(showDates.pad(top = 12))

        val saveBtn = Button(this).apply {
            text = "Сохранить"
            setOnClickListener { save() }
        }
        root.addView(saveBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        val scheduleBtn = Button(this).apply {
            text = "Расписание на день…"
            setOnClickListener {
                startActivity(Intent(this@ConfigActivity, ScheduleActivity::class.java))
            }
        }
        root.addView(scheduleBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            root.addView(
                text("Чтобы добавить виджет: долгое нажатие на главном экране → «Виджеты» → «Виджет недели».", 13f)
                    .pad(top = 12)
            )
        }

        numEdit.onChange { render() }
        denEdit.onChange { render() }

        setContentView(ScrollView(this).apply { addView(root) })
        render()
    }

    private fun render() {
        val num = currentIsNum
        val bg = if (num) numColor else denColor
        val fg = if (isLight(bg)) Color.BLACK else Color.WHITE
        pvCard.background = GradientDrawable().apply { setColor(bg); cornerRadius = dp(22).toFloat() }
        pvTitle.text = (if (num) numEdit.text else denEdit.text).toString()
        val monday = WeekLogic.mondayOf(LocalDate.now())
        val f = DateTimeFormatter.ofPattern("d MMM", Locale.forLanguageTag("ru"))
        pvSub.text = "${f.format(monday)} – ${f.format(monday.plusDays(6))}"
        pvSub.visibility = if (showDates.isChecked) View.VISIBLE else View.GONE
        listOf(pvCaption, pvTitle, pvSub).forEach { it.setTextColor(fg) }
    }

    private fun save() {
        val cfg = WidgetConfig(
            anchorMonday = WeekLogic.mondayOf(LocalDate.now()),
            anchorNumerator = currentIsNum,
            numLabel = numEdit.text.toString().ifBlank { "Над чертой" },
            denLabel = denEdit.text.toString().ifBlank { "Под чертой" },
            numColor = numColor,
            denColor = denColor,
            showDates = showDates.isChecked,
        )
        ConfigStore.save(this, widgetId, cfg)
        WeekWidgetProvider.updateAll(this)

        if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
            finish()
        } else {
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- helpers ----------

    private fun swatches(current: () -> Int, pick: (Int) -> Unit): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val items = mutableListOf<Pair<View, Int>>()
        fun refresh() {
            items.forEach { (v, c) ->
                v.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(c)
                    if (c == current()) setStroke(dp(3), Color.BLACK)
                }
            }
        }
        palette.forEach { c ->
            val v = View(this)
            v.layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(dp(4), dp(8), dp(4), dp(4)) }
            v.setOnClickListener { pick(c); refresh() }
            items += v to c
            row.addView(v)
        }
        refresh()
        return HorizontalScrollView(this).apply { addView(row) }
    }

    private fun text(s: String, size: Float, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun sectionTitle(s: String) = text(s, 15f, bold = true).pad(top = 20)

    private fun <T : View> T.pad(top: Int = 0): T {
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(top) }
        return this
    }

    private fun EditText.onChange(block: () -> Unit) {
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = block()
        })
    }

    private fun isLight(c: Int): Boolean =
        (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255 > 0.6

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
