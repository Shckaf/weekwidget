package com.example.weekwidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Экран ввода расписания: для каждого дня и для каждой недели (над/под чертой). */
class ScheduleActivity : Activity() {

    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private val data = mutableMapOf<String, String>()
    private var editingNum = false
    private var editingDow = 1
    private var currentIsNum = false
    private var bgColor = 0

    private lateinit var edit: EditText
    private lateinit var editTitle: TextView
    private val weekChips = mutableListOf<TextView>()
    private val dayChips = mutableListOf<TextView>()
    private val shortDays = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")

    private val palette = listOf(
        0xFF212529.toInt(), 0xFFF1F3F5.toInt(), 0xFF1E66F5.toInt(), 0xFFE8590C.toInt(),
        0xFF2F9E44.toInt(), 0xFF7048E8.toInt(), 0xFF0C8599.toInt(), 0xFFD6336C.toInt(),
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        widgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        setResult(RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))

        for (n in listOf(true, false)) for (d in 1..7) {
            data[ScheduleStore.key(n, d)] = ScheduleStore.getDay(this, n, d)
        }
        currentIsNum = ScheduleStore.isNumeratorToday(this)
        editingNum = currentIsNum
        editingDow = LocalDate.now().dayOfWeek.value
        bgColor = ScheduleStore.bg(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }

        root.addView(label("Расписание на день", 24f, bold = true))
        root.addView(label("Заполни пары для каждого дня. Виджет сам покажет нужный список на сегодня.", 14f, top = 4))

        // --- Какая неделя сейчас ---
        val monday = WeekLogic.mondayOf(LocalDate.now())
        val f = DateTimeFormatter.ofPattern("d MMM", Locale.forLanguageTag("ru"))
        root.addView(label("Какая неделя сейчас? (${f.format(monday)} – ${f.format(monday.plusDays(6))})", 15f, bold = true, top = 20))
        val group = RadioGroup(this)
        val rbNum = RadioButton(this).apply { text = "Над чертой (числитель)"; id = View.generateViewId() }
        val rbDen = RadioButton(this).apply { text = "Под чертой (знаменатель)"; id = View.generateViewId() }
        group.addView(rbNum)
        group.addView(rbDen)
        group.check(if (currentIsNum) rbNum.id else rbDen.id)
        group.setOnCheckedChangeListener { _, checked -> currentIsNum = checked == rbNum.id }
        root.addView(group)

        // --- Выбор недели и дня для редактирования ---
        root.addView(label("Что редактируем", 15f, bold = true, top = 20))
        val weekRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        weekChips += chip("Над чертой") { select(true, editingDow) }
        weekChips += chip("Под чертой") { select(false, editingDow) }
        weekChips.forEach { weekRow.addView(it) }
        root.addView(weekRow)

        val dayRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        shortDays.forEachIndexed { i, name ->
            val c = chip(name) { select(editingNum, i + 1) }
            dayChips += c
            dayRow.addView(c)
        }
        root.addView(HorizontalScrollView(this).apply { addView(dayRow) })

        editTitle = label("", 14f, bold = true, top = 12)
        root.addView(editTitle)

        edit = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            minLines = 8
            gravity = Gravity.TOP or Gravity.START
            hint = "Одна пара на строку, например:\n9:00 Математика, ауд. 305\n10:40 Физика, ауд. 112"
            setText(data[ScheduleStore.key(editingNum, editingDow)] ?: "")
        }
        root.addView(edit, LinearLayout.LayoutParams(-1, -2))

        val copyBtn = Button(this).apply {
            text = "Скопировать этот день на другую неделю"
            setOnClickListener {
                commit()
                data[ScheduleStore.key(!editingNum, editingDow)] = edit.text.toString()
                Toast.makeText(
                    this@ScheduleActivity,
                    "Скопировано на неделю «${if (editingNum) "под чертой" else "над чертой"}»",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        root.addView(copyBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        // --- Цвет фона ---
        root.addView(label("Цвет фона виджета", 15f, bold = true, top = 20))
        root.addView(swatches())

        val saveBtn = Button(this).apply {
            text = "Сохранить"
            setOnClickListener { save() }
        }
        root.addView(saveBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        setContentView(ScrollView(this).apply { addView(root) })
        restyle()
    }

    private fun commit() {
        data[ScheduleStore.key(editingNum, editingDow)] = edit.text.toString()
    }

    private fun select(num: Boolean, dow: Int) {
        commit()
        editingNum = num
        editingDow = dow
        edit.setText(data[ScheduleStore.key(num, dow)] ?: "")
        restyle()
    }

    private fun restyle() {
        styleChip(weekChips[0], editingNum)
        styleChip(weekChips[1], !editingNum)
        dayChips.forEachIndexed { i, c -> styleChip(c, i + 1 == editingDow) }
        editTitle.text = "${DAY_NAMES[editingDow - 1]}, ${if (editingNum) "над чертой" else "под чертой"}"
    }

    private fun save() {
        commit()
        ScheduleStore.save(this, data, WeekLogic.mondayOf(LocalDate.now()), currentIsNum, bgColor)
        ScheduleWidgetProvider.updateAll(this)
        if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        } else {
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
        }
        finish()
    }

    // ---------- helpers ----------

    private fun chip(text: String, onClick: () -> Unit): TextView {
        val v = TextView(this)
        v.text = text
        v.gravity = Gravity.CENTER
        v.textSize = 14f
        v.setPadding(dp(14), dp(8), dp(14), dp(8))
        v.layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) }
        v.setOnClickListener { onClick() }
        return v
    }

    private fun styleChip(v: TextView, on: Boolean) {
        v.background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setColor(if (on) 0xFF1E66F5.toInt() else 0xFFE9ECEF.toInt())
        }
        v.setTextColor(if (on) Color.WHITE else Color.BLACK)
    }

    private fun swatches(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val items = mutableListOf<Pair<View, Int>>()
        fun refresh() {
            items.forEach { (v, c) ->
                v.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(c)
                    setStroke(dp(if (c == bgColor) 3 else 1), if (c == bgColor) 0xFF1E66F5.toInt() else 0xFFADB5BD.toInt())
                }
            }
        }
        palette.forEach { c ->
            val v = View(this)
            v.layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(dp(4), dp(8), dp(4), dp(4)) }
            v.setOnClickListener { bgColor = c; refresh() }
            items += v to c
            row.addView(v)
        }
        refresh()
        return HorizontalScrollView(this).apply { addView(row) }
    }

    private fun label(s: String, size: Float, bold: Boolean = false, top: Int = 0): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        t.layoutParams = LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(top) }
        return t
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
