package com.example.weekwidget

import android.content.Context
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters

object WeekLogic {
    fun mondayOf(d: LocalDate): LocalDate =
        d.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))

    /** true = над чертой (числитель), false = под чертой (знаменатель) */
    fun isNumerator(today: LocalDate, anchorMonday: LocalDate, anchorNumerator: Boolean): Boolean {
        val weeks = ChronoUnit.WEEKS.between(mondayOf(anchorMonday), mondayOf(today))
        val sameAsAnchor = weeks % 2 == 0L
        return if (sameAsAnchor) anchorNumerator else !anchorNumerator
    }
}

data class WidgetConfig(
    val anchorMonday: LocalDate,
    val anchorNumerator: Boolean,
    val numLabel: String,
    val denLabel: String,
    val numColor: Int,
    val denColor: Int,
    val showDates: Boolean,
) {
    fun isNumerator(today: LocalDate = LocalDate.now()): Boolean =
        WeekLogic.isNumerator(today, anchorMonday, anchorNumerator)
}

/** Настройки хранятся по id виджета; id 0 — настройки по умолчанию. */
object ConfigStore {
    private const val FILE = "week_widget"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // 12 октября 2026 (понедельник) — неделя «под чертой».
    fun defaults() = WidgetConfig(
        anchorMonday = LocalDate.of(2026, 10, 12),
        anchorNumerator = false,
        numLabel = "Над чертой",
        denLabel = "Под чертой",
        numColor = 0xFF1E66F5.toInt(),
        denColor = 0xFFE8590C.toInt(),
        showDates = true,
    )

    fun load(ctx: Context, id: Int): WidgetConfig {
        val p = prefs(ctx)
        val k = if (p.contains("$id.anchor")) id else 0
        val d = defaults()
        return WidgetConfig(
            anchorMonday = p.getString("$k.anchor", null)?.let { LocalDate.parse(it) } ?: d.anchorMonday,
            anchorNumerator = p.getBoolean("$k.anchorNum", d.anchorNumerator),
            numLabel = p.getString("$k.numLabel", d.numLabel) ?: d.numLabel,
            denLabel = p.getString("$k.denLabel", d.denLabel) ?: d.denLabel,
            numColor = p.getInt("$k.numColor", d.numColor),
            denColor = p.getInt("$k.denColor", d.denColor),
            showDates = p.getBoolean("$k.showDates", d.showDates),
        )
    }

    fun save(ctx: Context, id: Int, c: WidgetConfig) {
        prefs(ctx).edit()
            .putString("$id.anchor", c.anchorMonday.toString())
            .putBoolean("$id.anchorNum", c.anchorNumerator)
            .putString("$id.numLabel", c.numLabel)
            .putString("$id.denLabel", c.denLabel)
            .putInt("$id.numColor", c.numColor)
            .putInt("$id.denColor", c.denColor)
            .putBoolean("$id.showDates", c.showDates)
            .apply()
    }

    fun delete(ctx: Context, id: Int) {
        val e = prefs(ctx).edit()
        listOf("anchor", "anchorNum", "numLabel", "denLabel", "numColor", "denColor", "showDates")
            .forEach { e.remove("$id.$it") }
        e.apply()
    }
}
