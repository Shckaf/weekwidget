package com.example.weekwidget

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.time.LocalTime

/** Тип занятия (значения совпадают с полем "type" в JSON). */
enum class LType(val badge: String, val label: String) {
    LECTURE("Лек", "Лекция"),
    LAB("Лаб", "Лабораторная работа"),
    PRACTICE("Пр", "Практическое занятие"),
    OTHER("", "");

    companion object {
        fun of(s: String) = values().firstOrNull { it.name == s } ?: OTHER
    }
}

const val SUB_ALL = 0
const val PARITY_EVERY = 0
const val PARITY_NUM = 1
const val PARITY_DEN = 2

class DbLesson(
    val weekday: Int,
    val parity: Int,
    val start: String,
    val end: String,
    val title: String,
    val type: LType,
    val subgroup: Int,
    val room: String,
    val teacher: String,
) {
    val startTime: LocalTime get() = LocalTime.parse(start)
    val endTime: LocalTime get() = LocalTime.parse(end)
}

/** Элемент дня: пара или «окно» (когда пара не для твоей подгруппы). */
class Slot(val lesson: DbLesson?, val start: LocalTime, val end: LocalTime) {
    val isWindow: Boolean get() = lesson == null
}

/** Выбор пользователя: факультет → группа → подгруппа. Хранится в SharedPreferences. */
object Profile {
    private fun p(ctx: Context) = ctx.getSharedPreferences("profile", Context.MODE_PRIVATE)

    fun groupId(ctx: Context): String = p(ctx).getString("groupId", "") ?: ""
    fun groupName(ctx: Context): String = p(ctx).getString("groupName", "") ?: ""
    /** 0 = вся группа, 1 = первая, 2 = вторая */
    fun subgroup(ctx: Context): Int = p(ctx).getInt("subgroup", SUB_ALL)
    fun showWindows(ctx: Context): Boolean = p(ctx).getBoolean("windows", false)
    fun isReady(ctx: Context) = groupId(ctx).isNotEmpty()

    fun save(ctx: Context, facultyId: String, groupId: String, groupName: String, subgroup: Int) {
        p(ctx).edit().putString("facultyId", facultyId).putString("groupId", groupId)
            .putString("groupName", groupName).putInt("subgroup", subgroup).apply()
    }

    fun setSubgroup(ctx: Context, s: Int) = p(ctx).edit().putInt("subgroup", s).apply()
    fun setShowWindows(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("windows", v).apply()
}

/**
 * Локальная БД (чистый SQLite из фреймворка — без новых зависимостей, собирается как сейчас).
 * Для Room таблица та же: @Entity(tableName="lesson") с теми же полями + @Dao с запросом ниже.
 */
class ScheduleDb(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "schedule.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE lesson(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                weekday INTEGER NOT NULL,      -- 1..7
                parity INTEGER NOT NULL,       -- 0 каждая, 1 над чертой, 2 под чертой
                start TEXT NOT NULL,           -- HH:MM
                end TEXT NOT NULL,
                title TEXT NOT NULL,
                type TEXT NOT NULL,            -- LECTURE/LAB/PRACTICE/OTHER
                subgroup INTEGER NOT NULL,     -- 0 вся группа, 1, 2
                room TEXT NOT NULL,
                teacher TEXT NOT NULL)"""
        )
        db.execSQL("CREATE INDEX idx_day ON lesson(weekday, parity, start)")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {
        db.execSQL("DROP TABLE IF EXISTS lesson"); onCreate(db)
    }

    /** Атомарно заменяет все пары. При ошибке остаются старые данные (офлайн-кэш). */
    fun replaceAll(items: List<DbLesson>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("lesson", null, null)
            for (l in items) {
                db.insertOrThrow("lesson", null, ContentValues().apply {
                    put("weekday", l.weekday); put("parity", l.parity)
                    put("start", l.start); put("end", l.end); put("title", l.title)
                    put("type", l.type.name); put("subgroup", l.subgroup)
                    put("room", l.room); put("teacher", l.teacher)
                })
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /** Все пары дня для нужной чётности (подгруппы ещё не отфильтрованы). */
    fun day(weekday: Int, numerator: Boolean): List<DbLesson> {
        val par = if (numerator) PARITY_NUM else PARITY_DEN
        val out = ArrayList<DbLesson>()
        readableDatabase.rawQuery(
            "SELECT weekday,parity,start,end,title,type,subgroup,room,teacher FROM lesson " +
                "WHERE weekday=? AND parity IN (0,?) ORDER BY start",
            arrayOf(weekday.toString(), par.toString())
        ).use { c ->
            while (c.moveToNext()) out += DbLesson(
                c.getInt(0), c.getInt(1), c.getString(2), c.getString(3), c.getString(4),
                LType.of(c.getString(5)), c.getInt(6), c.getString(7), c.getString(8)
            )
        }
        return out
    }
}

/** Фильтр по подгруппе. */
object SubgroupFilter {
    /**
     * @param sub выбранная подгруппа: 0 — показывать всё, 1/2 — свою + общие пары
     * @param windows true — вместо чужих пар показывать «окно» (если в это время у тебя ничего нет)
     */
    fun apply(day: List<DbLesson>, sub: Int, windows: Boolean): List<Slot> {
        val mine = day.filter { sub == SUB_ALL || it.subgroup == SUB_ALL || it.subgroup == sub }
        val slots = ArrayList<Slot>()
        mine.forEach { slots += Slot(it, it.startTime, it.endTime) }
        if (windows && sub != SUB_ALL) {
            val foreign = day.filter { it !in mine }
            for (f in foreign) {
                val overlaps = mine.any { it.startTime < f.endTime && f.startTime < it.endTime }
                val already = slots.any { it.isWindow && it.start == f.startTime }
                if (!overlaps && !already) slots += Slot(null, f.startTime, f.endTime)
            }
        }
        return slots.sortedBy { it.start }
    }
}
