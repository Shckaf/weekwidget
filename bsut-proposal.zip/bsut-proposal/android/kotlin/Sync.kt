package com.example.weekwidget

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/** Загрузка расписания с JSON-API (ветка data в GitHub). Нужен <uses-permission android.permission.INTERNET/>. */
object Sync {
    const val BASE = "https://raw.githubusercontent.com/Shckaf/weekwidget/data/"

    fun get(path: String): String {
        val c = URL(BASE + path).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 15_000
        try {
            if (c.responseCode != 200) throw java.io.IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** Список факультетов и групп (для онбординга). Вызывать не в главном потоке. */
    fun index(): JSONObject = JSONObject(get("index.json"))

    /** Скачивает пары выбранной группы в локальную БД. Колбэк — в главном потоке. */
    fun refresh(ctx: Context, onDone: (Boolean) -> Unit = {}) {
        val app = ctx.applicationContext
        val gid = Profile.groupId(app)
        thread {
            val ok = try {
                if (gid.isEmpty()) false else {
                    val arr = JSONObject(get("groups/$gid.json")).getJSONArray("lessons")
                    val list = (0 until arr.length()).map {
                        val o = arr.getJSONObject(it)
                        DbLesson(
                            o.getInt("weekday"), o.getInt("parity"), o.getString("start"), o.getString("end"),
                            o.getString("title"), LType.of(o.getString("type")), o.getInt("subgroup"),
                            o.optString("room"), o.optString("teacher")
                        )
                    }
                    ScheduleDb(app).replaceAll(list)
                    true
                }
            } catch (e: Exception) {
                false   // нет сети — остаётся прошлая копия
            }
            Handler(Looper.getMainLooper()).post {
                if (ok) TimelineWidgetProvider.updateAll(app)
                onDone(ok)
            }
        }
    }
}
