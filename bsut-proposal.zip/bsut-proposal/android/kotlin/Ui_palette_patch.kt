// В Ui.kt ЗАМЕНИТЬ строки с BLUE … SEGMENT (сейчас val с фиксированными цветами) на этот блок.
// Остальной код Ui.kt не меняется: он обращается к Ui.BG, Ui.CARD… в момент вызова.

    /** true, если система сейчас в тёмной теме. Выставляется в Ui.apply(activity). */
    @Volatile var night = false

    private fun pick(day: Long, dark: Long) = (if (night) dark else day).toInt()

    val BLUE get() = pick(0xFF1E66F5, 0xFF4C8DFF)
    val BLUE_SOFT get() = pick(0xFFE7EFFE, 0xFF1E2A44)
    val BG get() = pick(0xFFF5F6F8, 0xFF0F1115)
    val CARD get() = pick(0xFFFFFFFF, 0xFF1C1F24)
    val TEXT get() = pick(0xFF1B1F23, 0xFFECEFF4)
    val MUTED get() = pick(0xFF6B7280, 0xFF9AA3B2)
    val HINT get() = pick(0xFF9CA3AF, 0xFF6B7385)
    val LINE get() = pick(0xFFE5E7EB, 0xFF2E333B)
    val FIELD get() = pick(0xFFF3F4F6, 0xFF262A31)
    val SEGMENT get() = pick(0xFFE9ECF1, 0xFF262A31)

    /** Вызывать ПЕРВОЙ строкой в onCreate каждой Activity (до setContentView). */
    fun apply(a: android.app.Activity) {
        night = (a.resources.configuration.uiMode and
            android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        a.window.statusBarColor = BG
        a.window.navigationBarColor = BG
        // Светлые значки статус-бара только в светлой теме
        val flags = a.window.decorView.systemUiVisibility
        val light = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        a.window.decorView.systemUiVisibility = if (night) flags and light.inv() else flags or light
    }
