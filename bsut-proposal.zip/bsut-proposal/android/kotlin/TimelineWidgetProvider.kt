package com.example.weekwidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

/**
 * Широкий виджет «Таймлайн пар»: карточки слева направо.
 * Текущая пара — сплошная цветная плашка, прошедшие — приглушены, будущие — нейтральные.
 * Учитывает подгруппу (SubgroupFilter) и чётность недели.
 */
class TimelineWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(ctx, mgr, it) }
    }

    override fun onAppWidgetOptionsChanged(ctx: Context, mgr: AppWidgetManager, id: Int, newOptions: Bundle) {
        update(ctx, mgr, id)
    }

    override fun onDisabled(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java).cancel(alarmIntent(ctx))
    }

    companion object {
        private const val MAX = 6
        private val CARD = intArrayOf(R.id.tl0, R.id.tl1, R.id.tl2, R.id.tl3, R.id.tl4, R.id.tl5)
        private val TIME = intArrayOf(R.id.tl0_time, R.id.tl1_time, R.id.tl2_time, R.id.tl3_time, R.id.tl4_time, R.id.tl5_time)
        private val TITLE = intArrayOf(R.id.tl0_title, R.id.tl1_title, R.id.tl2_title, R.id.tl3_title, R.id.tl4_title, R.id.tl5_title)
        private val TYPE = intArrayOf(R.id.tl0_type, R.id.tl1_type, R.id.tl2_type, R.id.tl3_type, R.id.tl4_type, R.id.tl5_type)
        private val ROOM = intArrayOf(R.id.tl0_room, R.id.tl1_room, R.id.tl2_room, R.id.tl3_room, R.id.tl4_room, R.id.tl5_room)

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            mgr.getAppWidgetIds(ComponentName(ctx, TimelineWidgetProvider::class.java))
                .forEach { update(ctx, mgr, it) }
        }

        private fun shortType(t: LType) = when (t) {
            LType.LECTURE -> "Лекция"
            LType.LAB -> "Лаб. работа"
            LType.PRACTICE -> "Практика"
            LType.OTHER -> ""
        }

        private fun todaySlots(ctx: Context): List<Slot> {
            val dow = LocalDate.now().dayOfWeek.value
            val day = ScheduleDb(ctx).day(dow, ScheduleStore.isNumeratorToday(ctx))
            return SubgroupFilter.apply(day, Profile.subgroup(ctx), Profile.showWindows(ctx))
        }

        fun update(ctx: Context, mgr: AppWidgetManager, id: Int) {
            val (w, _) = WidgetSize.of(ctx, mgr, id, 250, 110)
            val count = (w / 80).coerceIn(2, MAX)
            val rv = RemoteViews(ctx.packageName, R.layout.widget_timeline)

            val tap = Intent(ctx, if (Profile.isReady(ctx)) MainActivity::class.java else OnboardingActivity::class.java)
            rv.setOnClickPendingIntent(
                R.id.tl_root,
                PendingIntent.getActivity(ctx, 0, tap, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            )

            val slots = if (Profile.isReady(ctx)) todaySlots(ctx) else emptyList()
            for (i in 0 until MAX) rv.setViewVisibility(CARD[i], View.GONE)

            if (slots.isEmpty()) {
                rv.setViewVisibility(R.id.tl_row, View.GONE)
                rv.setViewVisibility(R.id.tl_empty, View.VISIBLE)
                rv.setTextViewText(
                    R.id.tl_empty,
                    if (Profile.isReady(ctx)) "Сегодня пар нет" else "Выбери группу в приложении"
                )
            } else {
                rv.setViewVisibility(R.id.tl_row, View.VISIBLE)
                rv.setViewVisibility(R.id.tl_empty, View.GONE)
                val now = LocalTime.now()
                val cur = slots.indexOfFirst { now >= it.start && now < it.end }
                val focus = when {
                    cur >= 0 -> cur
                    else -> slots.indexOfFirst { it.start > now }.let { if (it < 0) slots.lastIndex else it }
                }
                val from = (focus - 1).coerceAtLeast(0).coerceAtMost((slots.size - count).coerceAtLeast(0))
                for (k in 0 until count) {
                    val idx = from + k
                    if (idx >= slots.size) break
                    bind(rv, k, slots[idx], idx == cur, slots[idx].end <= now)
                }
            }
            mgr.updateAppWidget(id, rv)
            scheduleNext(ctx, slots)
        }

        private fun bind(rv: RemoteViews, k: Int, s: Slot, current: Boolean, past: Boolean) {
            rv.setViewVisibility(CARD[k], View.VISIBLE)
            rv.setTextViewText(TIME[k], "${s.start}–${s.end}")
            val l = s.lesson
            rv.setTextViewText(TITLE[k], l?.title ?: "Окно")
            rv.setTextViewText(TYPE[k], if (l == null) "" else shortType(l.type))
            rv.setTextViewText(ROOM[k], if (l == null || l.room.isEmpty()) "" else "ауд. ${l.room}")
            if (current) {
                // Сплошная плашка. Фон — ресурс (подстраивается под тёмную тему лаунчером),
                // текст всегда белый: он читается на акценте и днём, и ночью.
                rv.setInt(CARD[k], "setBackgroundResource", R.drawable.tl_card_current)
                for (t in intArrayOf(TIME[k], TITLE[k])) rv.setTextColor(t, Color.WHITE)
                for (t in intArrayOf(TYPE[k], ROOM[k])) rv.setTextColor(t, 0xCCFFFFFF.toInt())
            }
            if (past) rv.setFloat(CARD[k], "setAlpha", 0.5f)
        }

        // ---- обновление в момент начала/конца пары ----

        private fun alarmIntent(ctx: Context): PendingIntent {
            val i = Intent(ctx, TimelineWidgetProvider::class.java).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
            val ids = AppWidgetManager.getInstance(ctx)
                .getAppWidgetIds(ComponentName(ctx, TimelineWidgetProvider::class.java))
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            return PendingIntent.getBroadcast(ctx, 77, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }

        private fun scheduleNext(ctx: Context, slots: List<Slot>) {
            val now = LocalTime.now()
            val boundary = slots.flatMap { listOf(it.start, it.end) }.filter { it > now }.minOrNull()
            val target = if (boundary != null) LocalDateTime.of(LocalDate.now(), boundary)
            else LocalDate.now().plusDays(1).atStartOfDay().plusSeconds(5)
            val ms = target.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            ctx.getSystemService(AlarmManager::class.java)
                .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, alarmIntent(ctx))
        }
    }
}
