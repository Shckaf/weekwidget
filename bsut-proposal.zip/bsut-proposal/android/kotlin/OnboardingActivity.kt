package com.example.weekwidget

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import kotlin.concurrent.thread

/**
 * Регистрация: Факультет → Курс (и специальность) → Группа → Подгруппа.
 * Один экран, содержимое перерисовывается по шагам; «Назад» возвращает на шаг назад.
 */
class OnboardingActivity : Activity() {

    private var step = 0
    private var faculties: JSONArray? = null
    private var faculty: JSONObject? = null
    private var course = 0
    private var group: JSONObject? = null
    private var subgroup = SUB_ALL   // по умолчанию «вся группа»
    private var windows = false

    private val body by lazy { column() }
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        subgroup = Profile.subgroup(this)
        windows = Profile.showWindows(this)
        setContentView(screen(titleHeader("Моя группа"), body, null))
        load()
    }

    private fun load() {
        body.removeAllViews()
        body.addView(tv("Загружаю список факультетов…", 15f, Ui.MUTED))
        thread {
            val res = try { Sync.index().getJSONArray("faculties") } catch (e: Exception) { null }
            ui.post {
                if (res == null) {
                    body.removeAllViews()
                    body.addView(tv("Нет связи с сервером расписания.", 15f, Ui.TEXT))
                    body.addView(button("Повторить") { load() }, lp(top = 12))
                } else {
                    faculties = res; step = 0; render()
                }
            }
        }
    }

    private fun render() {
        body.removeAllViews()
        when (step) {
            0 -> {
                body.addView(sectionTitle("Факультет"))
                val a = faculties!!
                for (i in 0 until a.length()) {
                    val f = a.getJSONObject(i)
                    body.addView(button(f.getString("name"), false) { faculty = f; step = 1; render() }, lp(top = 8))
                }
            }
            1 -> {
                body.addView(sectionTitle("Курс"))
                val courses = (0 until faculty!!.getJSONArray("groups").length())
                    .map { faculty!!.getJSONArray("groups").getJSONObject(it).getInt("course") }
                    .distinct().sorted()
                for (c in courses) {
                    body.addView(button("$c курс", false) { course = c; step = 2; render() }, lp(top = 8))
                }
            }
            2 -> {
                body.addView(sectionTitle("Группа"))
                val gs = faculty!!.getJSONArray("groups")
                for (i in 0 until gs.length()) {
                    val g = gs.getJSONObject(i)
                    if (g.getInt("course") != course) continue
                    val sub = g.optString("specialty")
                    body.addView(
                        button(if (sub.isEmpty()) g.getString("name") else "${g.getString("name")} · $sub", false) {
                            group = g; step = 3; render()
                        }, lp(top = 8)
                    )
                }
            }
            else -> renderSubgroup()
        }
    }

    private fun renderSubgroup() {
        body.addView(sectionTitle("Группа ${group!!.getString("name")}"))
        body.addView(tv("В какой ты подгруппе?", 14f, Ui.MUTED), lp(top = 2))
        // порядок кнопок: 1-я, 2-я, вся группа
        val labels = listOf("1-я подгруппа", "2-я подгруппа", "Вся группа")
        val sel = when (subgroup) { 1 -> 0; 2 -> 1; else -> 2 }
        body.addView(segmented(labels, sel) { subgroup = when (it) { 0 -> 1; 1 -> 2; else -> SUB_ALL } }, lp(top = 12))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(tv("Показывать «окно» вместо чужих пар", 15f), lp(w = 0, weight = 1f))
        row.addView(Switch(this).apply {
            isChecked = windows
            setOnCheckedChangeListener { _, v -> windows = v }
        })
        body.addView(row, lp(top = 16))

        body.addView(button("Готово") { finishRegistration() }, lp(top = 20))
    }

    private fun finishRegistration() {
        Profile.save(this, faculty!!.getString("id"), group!!.getString("id"), group!!.getString("name"), subgroup)
        Profile.setShowWindows(this, windows)
        Sync.refresh(this) { ok ->
            Toast.makeText(this, if (ok) "Расписание загружено" else "Не удалось загрузить — попробуем позже", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onBackPressed() {
        if (step > 0 && faculties != null) { step--; render() } else super.onBackPressed()
    }
}
