# Авто-расписание БелГУТ — предложение

* `backend/` — Python-парсер → нормализованный JSON (+ тесты: `python -m unittest discover -s tests`).
* `.github/workflows/schedule.yml` — раз в сутки собирает JSON и публикует в ветку `data`.
  Приложение читает `https://raw.githubusercontent.com/Shckaf/weekwidget/data/index.json` и т.д.
  Бесплатно, без своего сервера.
* `android/` — Kotlin/XML для приложения (НЕ подключено к проекту, не собиралось: в моей среде нет Android SDK).

Реальный формат сайта БелГУТа не проверен: `backend/run.py` содержит демо-данные, а адаптер
`parse_group_table` — пример под HTML-таблицу. Нужен реальный пример страницы расписания.
