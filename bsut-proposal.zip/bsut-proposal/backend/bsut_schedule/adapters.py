"""Адаптер источника.

ВАЖНО: реальный формат расписания БелГУТа (HTML / PDF / Excel / API) мне проверить не удалось —
сайт недоступен из моего окружения. Поэтому здесь:
  * интерфейс `Source` — то, что нужно реализовать под реальный формат;
  * `HtmlTableSource` — ПРИМЕР для типичной HTML-таблицы (день | время | ячейка с текстом).
    Селекторы и порядок колонок — ДОПУЩЕНИЕ, их надо подогнать под настоящую страницу.
"""
from __future__ import annotations

from typing import Iterable, List, Protocol

from bs4 import BeautifulSoup

from .models import Lesson, Group
from . import normalize as nz

DAYS = {"пн": 1, "вт": 2, "ср": 3, "чт": 4, "пт": 5, "сб": 6, "вс": 7,
        "понедельник": 1, "вторник": 2, "среда": 3, "четверг": 4,
        "пятница": 5, "суббота": 6, "воскресенье": 7}


class Source(Protocol):
    def groups(self) -> Iterable[Group]: ...


def parse_cell(weekday: int, time_text: str, cell_text: str) -> Lesson | None:
    """Одна ячейка расписания -> Lesson. Время берётся из колонки времени или из самой ячейки."""
    rng = nz.parse_time_range(time_text) or nz.parse_time_range(cell_text)
    title = nz.clean_title(cell_text)
    if not rng or not title:
        return None
    return Lesson(
        weekday=weekday,
        parity=nz.detect_parity(cell_text),
        start=rng[0],
        end=rng[1],
        title=title,
        type=nz.detect_type(cell_text),
        subgroup=nz.detect_subgroup(cell_text),
        room=nz.parse_room(cell_text),
    )


def parse_group_table(html: str) -> List[Lesson]:
    """ПРИМЕР: <table> со строками [день, время, описание]. День может быть только в первой строке дня."""
    soup = BeautifulSoup(html, "html.parser")
    out: List[Lesson] = []
    day = 0
    for tr in soup.select("table tr"):
        cells = [c.get_text(" ", strip=True) for c in tr.find_all(["td", "th"])]
        if len(cells) < 2:
            continue
        head = cells[0].lower().strip(". ")
        if head in DAYS:
            day = DAYS[head]
            cells = cells[1:]
        elif head == "" and len(cells) >= 3:
            cells = cells[1:]  # пустая ячейка дня: продолжение предыдущего дня
        if not day or len(cells) < 2:
            continue
        # В одной строке могут быть несколько пар (по подгруппам) через « / » или перенос.
        for part in [p for p in cells[1].replace("\n", " / ").split(" / ") if p.strip()]:
            lesson = parse_cell(day, cells[0], f"{cells[0]} {part}")
            if lesson:
                out.append(lesson)
    return out
