"""Разбор «грязных» строк расписания: тип занятия, подгруппа, чётность, время, аудитория."""
from __future__ import annotations

import re
from typing import Optional, Tuple

from .models import LECTURE, LAB, PRACTICE, OTHER, ALL, SUB1, SUB2, EVERY, NUM, DEN

_TYPE_RULES = [
    (LECTURE, re.compile(r"\b(лек(?:ция|\.)?|лк|л\.)(?=\W|$)", re.I)),
    (LAB, re.compile(r"\b(лаб(?:ораторная)?(?:\s+работа)?|лр|лаб\.)(?=\W|$)", re.I)),
    (PRACTICE, re.compile(r"\b(пр(?:актическое)?(?:\s+занятие)?|пз|пр\.)(?=\W|$)", re.I)),
]

_SUB_RULES = [
    (SUB1, re.compile(r"(?:\b1\s*[-–]?\s*я?\s*(?:п/?гр\.?|подгр(?:уппа|\.)?)|\(\s*1\s*(?:п/?гр|подгр)\.?\s*\)|п/?гр\.?\s*1\b|подгр(?:уппа|\.)?\s*1\b)", re.I)),
    (SUB2, re.compile(r"(?:\b2\s*[-–]?\s*я?\s*(?:п/?гр\.?|подгр(?:уппа|\.)?)|\(\s*2\s*(?:п/?гр|подгр)\.?\s*\)|п/?гр\.?\s*2\b|подгр(?:уппа|\.)?\s*2\b)", re.I)),
]

_PARITY_RULES = [
    (NUM, re.compile(r"(над\s+чертой|числит\w*|\bчис\.?\b|\bнеч[её]т\w*)", re.I)),
    (DEN, re.compile(r"(под\s+чертой|знаменат\w*|\bзнам\.?\b|\bч[её]тн\w*)", re.I)),
]

_ROOM = re.compile(r"(?:ауд\.?|а\.)\s*([0-9]{1,4}[а-яa-z]?(?:\s*[-/]\s*[0-9]{1,3})?)", re.I)
_TIME = re.compile(r"(\d{1,2})[:.](\d{2})\s*[-–—]\s*(\d{1,2})[:.](\d{2})")


def detect_type(text: str) -> str:
    for t, rx in _TYPE_RULES:
        if rx.search(text):
            return t
    return OTHER


def detect_subgroup(text: str) -> int:
    for s, rx in _SUB_RULES:
        if rx.search(text):
            return s
    return ALL


def detect_parity(text: str) -> int:
    for p, rx in _PARITY_RULES:
        if rx.search(text):
            return p
    return EVERY


def parse_time_range(text: str) -> Optional[Tuple[str, str]]:
    m = _TIME.search(text)
    if not m:
        return None
    a, b, c, d = (int(x) for x in m.groups())
    if not (0 <= a < 24 and 0 <= c < 24 and b < 60 and d < 60):
        return None
    return f"{a:02d}:{b:02d}", f"{c:02d}:{d:02d}"


def parse_room(text: str) -> str:
    m = _ROOM.search(text)
    return m.group(1).replace(" ", "") if m else ""


def clean_title(text: str) -> str:
    """Убирает из названия служебные пометки (тип, подгруппа, чётность, аудиторию)."""
    t = text
    for _, rx in _SUB_RULES + _PARITY_RULES + _TYPE_RULES:
        t = rx.sub("", t)
    t = _ROOM.sub("", t)
    t = _TIME.sub("", t)
    t = re.sub(r"\(\s*\)", "", t)
    t = re.sub(r"\s{2,}", " ", t)
    return t.strip(" ,;.-–—")
