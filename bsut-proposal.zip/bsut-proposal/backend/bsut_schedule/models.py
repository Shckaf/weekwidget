"""Нормализованная модель расписания. Один контракт для приложения, независимо от источника."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import List

# Тип занятия
LECTURE, LAB, PRACTICE, OTHER = "LECTURE", "LAB", "PRACTICE", "OTHER"
# Подгруппа: 0 = вся группа, 1 = первая, 2 = вторая
ALL, SUB1, SUB2 = 0, 1, 2
# Неделя: 0 = каждая, 1 = над чертой (числитель), 2 = под чертой (знаменатель)
EVERY, NUM, DEN = 0, 1, 2


@dataclass
class Lesson:
    weekday: int          # 1..7 (пн..вс)
    parity: int           # EVERY / NUM / DEN
    start: str            # "HH:MM"
    end: str              # "HH:MM"
    title: str
    type: str = OTHER     # LECTURE / LAB / PRACTICE / OTHER
    subgroup: int = ALL   # ALL / SUB1 / SUB2
    room: str = ""
    teacher: str = ""


@dataclass
class Group:
    id: str
    name: str
    course: int
    specialty: str
    lessons: List[Lesson] = field(default_factory=list)


@dataclass
class Faculty:
    id: str
    name: str
    groups: List[Group] = field(default_factory=list)


def to_dict(obj):
    return asdict(obj)
