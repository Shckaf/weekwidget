"""Сборка JSON-файлов для приложения + защита от «пустого» результата.

Выход:
  out/index.json                 — факультеты и группы (для онбординга)
  out/groups/<group_id>.json     — пары одной группы
  out/version.json               — метка версии для быстрой проверки обновлений
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
import time
from typing import Iterable, List

from .models import Faculty, Group, to_dict

MIN_RATIO = 0.5  # если пар стало меньше половины от прошлых — считаем, что парсер сломался


def _dump(path: str, data) -> str:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    text = json.dumps(data, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    return hashlib.sha1(text.encode()).hexdigest()


def count_lessons(faculties: Iterable[Faculty]) -> int:
    return sum(len(g.lessons) for f in faculties for g in f.groups)


def previous_count(out_dir: str) -> int:
    try:
        with open(os.path.join(out_dir, "version.json"), encoding="utf-8") as f:
            return int(json.load(f).get("lessons", 0))
    except (OSError, ValueError):
        return 0


def build(faculties: List[Faculty], out_dir: str) -> None:
    total = count_lessons(faculties)
    prev = previous_count(out_dir)
    if total == 0 or (prev and total < prev * MIN_RATIO):
        print(f"ОШИБКА: пар {total}, раньше {prev}. Публикацию отменяю, оставляю старые данные.", file=sys.stderr)
        raise SystemExit(1)

    index = []
    digests = []
    for fac in faculties:
        groups_meta = []
        for g in fac.groups:
            h = _dump(os.path.join(out_dir, "groups", f"{g.id}.json"),
                      {"id": g.id, "name": g.name, "lessons": [to_dict(l) for l in g.lessons]})
            digests.append(h)
            groups_meta.append({"id": g.id, "name": g.name, "course": g.course,
                                "specialty": g.specialty, "hash": h})
        index.append({"id": fac.id, "name": fac.name, "groups": groups_meta})

    _dump(os.path.join(out_dir, "index.json"), {"faculties": index})
    version = hashlib.sha1("".join(sorted(digests)).encode()).hexdigest()[:12]
    _dump(os.path.join(out_dir, "version.json"),
          {"version": version, "lessons": total, "generated": int(time.time())})
