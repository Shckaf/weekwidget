"""Точка входа: python run.py out/
Здесь нужно подставить реальный источник. Пока — демо-данные, чтобы пайплайн и приложение можно было проверить целиком."""
import sys

from bsut_schedule.build import build
from bsut_schedule.models import Faculty, Group
from bsut_schedule.adapters import parse_group_table

DEMO_HTML = """
<table>
<tr><td>пн</td><td>8:30-10:00</td><td>Высшая математика, лекция, ауд. 301</td></tr>
<tr><td></td><td>10:10-11:40</td><td>Программирование, лаб. 1 подгр. ауд. 215 / Программирование, лаб. 2 подгр. ауд. 217</td></tr>
<tr><td>вт</td><td>11:50-13:20</td><td>Физика, пр. занятие, под чертой, ауд. 105</td></tr>
</table>
"""


def main(out: str) -> None:
    group = Group(id="demo-1", name="Демо-группа", course=2, specialty="Демо",
                  lessons=parse_group_table(DEMO_HTML))
    build([Faculty(id="demo", name="Демо-факультет", groups=[group])], out)


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "out")
