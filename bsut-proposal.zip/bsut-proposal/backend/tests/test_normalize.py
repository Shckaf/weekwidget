import json
import os
import tempfile
import unittest

from bsut_schedule import normalize as nz
from bsut_schedule.adapters import parse_group_table, parse_cell
from bsut_schedule.build import build
from bsut_schedule.models import *


class Normalize(unittest.TestCase):
    def test_type(self):
        self.assertEqual(nz.detect_type("Математика, лекция"), LECTURE)
        self.assertEqual(nz.detect_type("Физика лаб. работа"), LAB)
        self.assertEqual(nz.detect_type("Физика, лабораторная работа"), LAB)
        self.assertEqual(nz.detect_type("История пр. занятие"), PRACTICE)
        self.assertEqual(nz.detect_type("Что-то"), OTHER)

    def test_subgroup(self):
        self.assertEqual(nz.detect_subgroup("Прог. лаб. 1 подгр. ауд. 2"), SUB1)
        self.assertEqual(nz.detect_subgroup("Прог. (2 п/гр)"), SUB2)
        self.assertEqual(nz.detect_subgroup("Прог. 2-я подгруппа"), SUB2)
        self.assertEqual(nz.detect_subgroup("Прог. подгруппа 1"), SUB1)
        self.assertEqual(nz.detect_subgroup("Прог. лекция"), ALL)

    def test_parity(self):
        self.assertEqual(nz.detect_parity("над чертой"), NUM)
        self.assertEqual(nz.detect_parity("Физика, под чертой"), DEN)
        self.assertEqual(nz.detect_parity("Физика"), EVERY)

    def test_time_room(self):
        self.assertEqual(nz.parse_time_range("8:30-10:00"), ("08:30", "10:00"))
        self.assertEqual(nz.parse_time_range("08.30 – 10.00"), ("08:30", "10:00"))
        self.assertIsNone(nz.parse_time_range("25:00-26:00"))
        self.assertEqual(nz.parse_room("ауд. 301"), "301")
        self.assertEqual(nz.parse_room("ауд.215а"), "215а")

    def test_clean_title(self):
        self.assertEqual(nz.clean_title("Программирование, лаб. 1 подгр. ауд. 215"), "Программирование")

    def test_table(self):
        html = """<table>
        <tr><td>пн</td><td>8:30-10:00</td><td>Математика, лекция, ауд. 301</td></tr>
        <tr><td></td><td>10:10-11:40</td><td>Прог., лаб. 1 подгр. ауд. 215 / Прог., лаб. 2 подгр. ауд. 217</td></tr>
        <tr><td>вт</td><td>11:50-13:20</td><td>Физика, пр., под чертой, ауд. 105</td></tr></table>"""
        ls = parse_group_table(html)
        self.assertEqual(len(ls), 4)
        self.assertEqual(ls[0].title, "Математика")
        self.assertEqual((ls[1].subgroup, ls[1].room, ls[1].type), (SUB1, "215", LAB))
        self.assertEqual((ls[2].subgroup, ls[2].room), (SUB2, "217"))
        self.assertEqual((ls[3].weekday, ls[3].parity, ls[3].type), (2, DEN, PRACTICE))

    def test_cell_without_time(self):
        self.assertIsNone(parse_cell(1, "", "Математика"))


class Build(unittest.TestCase):
    def _fac(self, n):
        g = Group("g1", "Г-1", 1, "S", [Lesson(1, 0, "08:30", "10:00", "X") for _ in range(n)])
        return [Faculty("f", "F", [g])]

    def test_build_and_guard(self):
        with tempfile.TemporaryDirectory() as d:
            build(self._fac(10), d)
            self.assertTrue(os.path.exists(os.path.join(d, "groups", "g1.json")))
            with open(os.path.join(d, "version.json")) as f:
                self.assertEqual(json.load(f)["lessons"], 10)
            with self.assertRaises(SystemExit):
                build(self._fac(2), d)   # резкое падение — отказ
            with self.assertRaises(SystemExit):
                build(self._fac(0), d)   # пусто — отказ
            build(self._fac(8), d)       # небольшое падение — ок


if __name__ == "__main__":
    unittest.main()
