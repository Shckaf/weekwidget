package com.example.weekwidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.ZoneId

val DAY_NAMES = listOf("Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье")
val DAY_SHORT = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")

object ScheduleStore {
    private const val FILE = "schedule"
    private fun p(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    /** num = над чертой, dow = 1 (пн) .. 7 (вс) */
    fun key(num: Boolean, dow: Int) = "${if (num) "num" else "den"}.$dow"

    fun getDay(ctx: Context, num: Boolean, dow: Int): String =
        p(ctx).getString(key(num, dow), "") ?: ""

    // Если «какая неделя сейчас» не задана здесь — берём из настроек виджета «Неделя».
    fun anchorMonday(ctx: Context): LocalDate =
        p(ctx).getString("anchor", null)?.let { LocalDate.parse(it) } ?: ConfigStore.loadForUi(ctx).anchorMonday

    fun anchorNumerator(ctx: Context): Boolean =
        if (p(ctx).contains("anchorNum")) p(ctx).getBoolean("anchorNum", false)
        else ConfigStore.loadForUi(ctx).anchorNumerator

    fun bg(ctx: Context): Int = p(ctx).getInt("bg", 0xFF212529.toInt())

    /** Для расписания по умолчанию — по левому краю: так списку пар читать удобнее. */
    fun align(ctx: Context): Int = p(ctx).getInt("align", ALIGN_LEFT)

    fun isNumeratorToday(ctx: Context): Boolean =
        WeekLogic.isNumerator(LocalDate.now(), anchorMonday(ctx), anchorNumerator(ctx))

    fun save(
        ctx: Context,
        days: Map<String, String>,
        anchorMonday: LocalDate,
        anchorNum: Boolean,
        bg: Int,
        align: Int,
    ) {
        val e = p(ctx).edit()
        days.forEach { (k, v) -> e.putString(k, v) }
        e.putString("anchor", anchorMonday.toString())
        e.putBoolean("anchorNum", anchorNum)
        e.putInt("bg", bg)
        e.putInt("align", align)
        e.apply()
    }
}

/**
 * Виджет «Расписание». Содержимое перестраивается под размер:
 *  - COMPACT (маленький): короткий заголовок и только то, что помещается;
 *  - DAY (обычный): пары на сегодня;
 *  - WEEK (большой): вся неделя — по строке на каждый день, сегодняшний выделен.
 */
class ScheduleWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(ctx, mgr, it) }
        scheduleMidnight(ctx)
    }

    /** Пользователь растянул или сжал виджет — выбираем подходящий режим заново. */
    override fun onAppWidgetOptionsChanged(ctx: Context, mgr: AppWidgetManager, id: Int, newOptions: Bundle) {
        update(ctx, mgr, id)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        when (intent.action) {
            ACTION_MIDNIGHT,
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED -> updateAll(ctx)
        }
    }

    override fun onDisabled(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java).cancel(midnightIntent(ctx))
    }

    companion object {
        private const val ACTION_MIDNIGHT = "com.example.weekwidget.SCHEDULE_MIDNIGHT"

        private const val MODE_COMPACT = 0
        private const val MODE_DAY = 1
        private const val MODE_WEEK = 2

        // Пороги в dp. Ячейка лаунчера ≈ 70dp: n ячеек ≈ 70·n − 30.
        private const val WEEK_MIN_W = 230   // от ~4 ячеек в ширину
        private const val WEEK_MIN_H = 230   // от ~4 ячеек в высоту
        private const val COMPACT_W = 150    // уже ~3 ячеек
        private const val COMPACT_H = 105    // ниже ~2 ячеек

        private val NAME_IDS = intArrayOf(R.id.d1_name, R.id.d2_name, R.id.d3_name, R.id.d4_name, R.id.d5_name, R.id.d6_name, R.id.d7_name)
        private val BODY_IDS = intArrayOf(R.id.d1_body, R.id.d2_body, R.id.d3_body, R.id.d4_body, R.id.d5_body, R.id.d6_body, R.id.d7_body)
        private val BOX_IDS = intArrayOf(R.id.d1_box, R.id.d2_box, R.id.d3_box, R.id.d4_box, R.id.d5_box, R.id.d6_box, R.id.d7_box)

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, ScheduleWidgetProvider::class.java))
            ids.forEach { update(ctx, mgr, it) }
            scheduleMidnight(ctx)
        }

        private fun modeFor(w: Int, h: Int): Int = when {
            w >= WEEK_MIN_W && h >= WEEK_MIN_H -> MODE_WEEK
            w < COMPACT_W || h < COMPACT_H -> MODE_COMPACT
            else -> MODE_DAY
        }

        fun update(ctx: Context, mgr: AppWidgetManager, id: Int) {
            val today = LocalDate.now()
            val num = ScheduleStore.isNumeratorToday(ctx)
            val bg = ScheduleStore.bg(ctx)
            val fg = Ui.contrast(bg)
            val (w, h) = WidgetSize.of(ctx, mgr, id, 250, 180)

            val rv = when (modeFor(w, h)) {
                MODE_WEEK -> buildWeek(ctx, today, num, bg, fg)
                MODE_COMPACT -> buildDay(ctx, today, num, bg, fg, h, compact = true)
                else -> buildDay(ctx, today, num, bg, fg, h, compact = false)
            }

            val open = Intent(ctx, ScheduleActivity::class.java)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            val pi = PendingIntent.getActivity(
                ctx, id + 100000, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            rv.setOnClickPendingIntent(R.id.root, pi)
            mgr.updateAppWidget(id, rv)
        }

        private fun linesOf(ctx: Context, num: Boolean, dow: Int): List<String> =
            ScheduleStore.getDay(ctx, num, dow).lines().map { it.trim() }.filter { it.isNotEmpty() }

        /** Сегодняшний день: заголовок + список пар. */
        private fun buildDay(
            ctx: Context, today: LocalDate, num: Boolean, bg: Int, fg: Int, hDp: Int, compact: Boolean,
        ): RemoteViews {
            val align = ScheduleStore.align(ctx)
            val layout = if (align == ALIGN_CENTER) R.layout.widget_schedule_center else R.layout.widget_schedule
            val rv = RemoteViews(ctx.packageName, layout)
            rv.setInt(R.id.bg, "setColorFilter", bg)

            val dow = today.dayOfWeek.value
            val head = if (compact) {
                "${DAY_SHORT[dow - 1]} · ${if (num) "над" else "под"}"
            } else {
                "${DAY_NAMES[dow - 1]} · ${if (num) "над чертой" else "под чертой"}"
            }

            // Сколько строк реально поместится при минимальном размере шрифта (8sp ≈ 12dp на строку).
            // Остальные сворачиваем в «… ещё N», чтобы текст не обрезался посреди пары.
            val all = linesOf(ctx, num, dow)
            val bodyDp = (hDp - 24) * 0.85f
            val cap = (bodyDp / 12f).toInt().coerceIn(1, 12)
            val shown = if (all.size > cap) all.take(cap - 1) + "… ещё ${all.size - cap + 1}" else all

            rv.setTextViewText(R.id.head, head)
            rv.setTextViewText(R.id.body, if (shown.isEmpty()) "Занятий нет" else shown.joinToString("\n"))
            rv.setTextColor(R.id.head, fg)
            rv.setTextColor(R.id.body, fg)
            return rv
        }

        /** Вся неделя: по строке на день, сегодняшний подсвечен. */
        private fun buildWeek(ctx: Context, today: LocalDate, num: Boolean, bg: Int, fg: Int): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_schedule_week)
            rv.setInt(R.id.bg, "setColorFilter", bg)
            rv.setTextViewText(R.id.head, "Неделя · ${if (num) "над чертой" else "под чертой"}")
            rv.setTextColor(R.id.head, fg)

            val highlight = (fg and 0x00FFFFFF) or 0x26000000
            val todayDow = today.dayOfWeek.value
            for (d in 1..7) {
                val items = linesOf(ctx, num, d)
                    .mapNotNull { Lessons.parseLine(it) }
                    .map { Lessons.compact(it) }
                rv.setTextViewText(NAME_IDS[d - 1], DAY_SHORT[d - 1])
                rv.setTextViewText(BODY_IDS[d - 1], if (items.isEmpty()) "—" else items.joinToString(" · "))
                rv.setTextColor(NAME_IDS[d - 1], fg)
                rv.setTextColor(BODY_IDS[d - 1], fg)
                rv.setInt(BOX_IDS[d - 1], "setBackgroundColor", if (d == todayDow) highlight else Color.TRANSPARENT)
            }
            return rv
        }

        private fun midnightIntent(ctx: Context): PendingIntent {
            val i = Intent(ctx, ScheduleWidgetProvider::class.java).setAction(ACTION_MIDNIGHT)
            return PendingIntent.getBroadcast(
                ctx, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private fun scheduleMidnight(ctx: Context) {
            val next = LocalDate.now().plusDays(1)
                .atStartOfDay(ZoneId.systemDefault()).plusSeconds(5)
                .toInstant().toEpochMilli()
            ctx.getSystemService(AlarmManager::class.java)
                .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, midnightIntent(ctx))
        }
    }
}
