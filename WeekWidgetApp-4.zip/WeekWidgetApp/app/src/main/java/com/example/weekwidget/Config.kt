package com.example.weekwidget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters

object WeekLogic {
    fun mondayOf(d: LocalDate): LocalDate =
        d.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))

    /** true = над чертой (числитель), false = под чертой (знаменатель) */
    fun isNumerator(today: LocalDate, anchorMonday: LocalDate, anchorNumerator: Boolean): Boolean {
        val weeks = ChronoUnit.WEEKS.between(mondayOf(anchorMonday), mondayOf(today))
        val sameAsAnchor = weeks % 2 == 0L
        return if (sameAsAnchor) anchorNumerator else !anchorNumerator
    }
}

/** Выравнивание текста в виджете. */
const val ALIGN_CENTER = 0
const val ALIGN_LEFT = 1

data class WidgetConfig(
    val anchorMonday: LocalDate,
    val anchorNumerator: Boolean,
    val numLabel: String,
    val denLabel: String,
    val numColor: Int,
    val denColor: Int,
    val showDates: Boolean,
    val align: Int = ALIGN_CENTER,
) {
    fun isNumerator(today: LocalDate = LocalDate.now()): Boolean =
        WeekLogic.isNumerator(today, anchorMonday, anchorNumerator)
}

/** Настройки хранятся по id виджета; id 0 — настройки по умолчанию. */
object ConfigStore {
    private const val FILE = "week_widget"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // 12 октября 2026 (понедельник) — неделя «под чертой».
    fun defaults() = WidgetConfig(
        anchorMonday = LocalDate.of(2026, 10, 12),
        anchorNumerator = false,
        numLabel = "Над чертой",
        denLabel = "Под чертой",
        numColor = 0xFF1E66F5.toInt(),
        denColor = 0xFFE8590C.toInt(),
        showDates = true,
    )

    fun load(ctx: Context, id: Int): WidgetConfig {
        val p = prefs(ctx)
        val k = if (p.contains("$id.anchor")) id else 0
        val d = defaults()
        return WidgetConfig(
            anchorMonday = p.getString("$k.anchor", null)?.let { LocalDate.parse(it) } ?: d.anchorMonday,
            anchorNumerator = p.getBoolean("$k.anchorNum", d.anchorNumerator),
            numLabel = p.getString("$k.numLabel", d.numLabel) ?: d.numLabel,
            denLabel = p.getString("$k.denLabel", d.denLabel) ?: d.denLabel,
            numColor = p.getInt("$k.numColor", d.numColor),
            denColor = p.getInt("$k.denColor", d.denColor),
            showDates = p.getBoolean("$k.showDates", d.showDates),
            align = p.getInt("$k.align", d.align),
        )
    }

    fun save(ctx: Context, id: Int, c: WidgetConfig) {
        prefs(ctx).edit()
            .putString("$id.anchor", c.anchorMonday.toString())
            .putBoolean("$id.anchorNum", c.anchorNumerator)
            .putString("$id.numLabel", c.numLabel)
            .putString("$id.denLabel", c.denLabel)
            .putInt("$id.numColor", c.numColor)
            .putInt("$id.denColor", c.denColor)
            .putBoolean("$id.showDates", c.showDates)
            .putInt("$id.align", c.align)
            .apply()
    }

    private fun widgetIds(ctx: Context): IntArray =
        AppWidgetManager.getInstance(ctx)
            .getAppWidgetIds(ComponentName(ctx, WeekWidgetProvider::class.java))

    /** Настройки для экрана приложения: берём общие, а если их нет — у первого виджета на экране. */
    fun loadForUi(ctx: Context): WidgetConfig {
        if (prefs(ctx).contains("0.anchor")) return load(ctx, 0)
        val first = widgetIds(ctx).firstOrNull()
        return if (first != null) load(ctx, first) else load(ctx, 0)
    }

    /** Сохранение с экрана приложения: общие настройки + все уже добавленные виджеты. */
    fun saveForUi(ctx: Context, c: WidgetConfig) {
        save(ctx, 0, c)
        widgetIds(ctx).forEach { save(ctx, it, c) }
    }

    fun delete(ctx: Context, id: Int) {
        val e = prefs(ctx).edit()
        listOf("anchor", "anchorNum", "numLabel", "denLabel", "numColor", "denColor", "showDates", "align")
            .forEach { e.remove("$id.$it") }
        e.apply()
    }
}
