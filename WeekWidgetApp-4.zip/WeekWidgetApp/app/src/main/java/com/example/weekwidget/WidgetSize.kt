package com.example.weekwidget

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.res.Configuration

/** Текущий размер виджета на главном экране, в dp. */
object WidgetSize {
    /**
     * Лаунчер сообщает размеры в Bundle опций виджета. В портрете виджет «уже и выше»
     * (MIN_WIDTH × MAX_HEIGHT), в ландшафте — «шире и ниже» (MAX_WIDTH × MIN_HEIGHT).
     * Если лаунчер размеры не прислал (бывает сразу после добавления), берём значения по умолчанию.
     */
    fun of(ctx: Context, mgr: AppWidgetManager, id: Int, defaultW: Int, defaultH: Int): Pair<Int, Int> {
        val o = mgr.getAppWidgetOptions(id)
        val land = ctx.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val w = if (land) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0)
        else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        val h = if (land) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0)
        else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        return (if (w > 0) w else defaultW) to (if (h > 0) h else defaultH)
    }
}
