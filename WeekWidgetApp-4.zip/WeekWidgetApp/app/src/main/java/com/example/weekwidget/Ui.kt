package com.example.weekwidget

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

const val MATCH = -1
const val WRAP = -2

/** Палитра и константы приложения. */
object Ui {
    val BLUE = 0xFF1E66F5.toInt()
    val BLUE_SOFT = 0xFFE7EFFE.toInt()
    val BG = 0xFFF5F6F8.toInt()
    val CARD = 0xFFFFFFFF.toInt()
    val TEXT = 0xFF1B1F23.toInt()
    val MUTED = 0xFF6B7280.toInt()
    val HINT = 0xFF9CA3AF.toInt()
    val LINE = 0xFFE5E7EB.toInt()
    val FIELD = 0xFFF3F4F6.toInt()
    val SEGMENT = 0xFFE9ECF1.toInt()

    val PALETTE = listOf(
        0xFF1E66F5.toInt(), 0xFFE8590C.toInt(), 0xFF2F9E44.toInt(), 0xFF7048E8.toInt(),
        0xFFE03131.toInt(), 0xFF343A40.toInt(), 0xFF0C8599.toInt(), 0xFFD6336C.toInt(),
        0xFF212529.toInt(), 0xFFF1F3F5.toInt(),
    )

    const val TELEGRAM_URL = "https://t.me/weekwidget"
    const val CREDIT = "by POTAPOV ILYA group EM <3"

    fun isLight(c: Int): Boolean =
        (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255 > 0.6

    fun contrast(bg: Int): Int = if (isLight(bg)) Color.BLACK else Color.WHITE
}

// ---------- базовые помощники ----------

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.lp(
    w: Int = MATCH, h: Int = WRAP,
    top: Int = 0, bottom: Int = 0, start: Int = 0, end: Int = 0,
    weight: Float = 0f,
): LinearLayout.LayoutParams =
    LinearLayout.LayoutParams(w, h, weight).apply { setMargins(dp(start), dp(top), dp(end), dp(bottom)) }

fun Context.shape(color: Int, radiusDp: Int = 16, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        if (strokeDp > 0) setStroke(dp(strokeDp), strokeColor)
    }

fun Context.oval(color: Int): GradientDrawable =
    GradientDrawable().apply {
        setShape(GradientDrawable.OVAL)
        setColor(color)
    }

fun Context.ripple(content: Drawable, radiusDp: Int = 14): RippleDrawable =
    RippleDrawable(ColorStateList.valueOf(0x22000000), content, shape(Color.WHITE, radiusDp))

fun Context.tv(s: CharSequence, sp: Float = 15f, color: Int = Ui.TEXT, bold: Boolean = false): TextView =
    TextView(this).apply {
        text = s
        textSize = sp
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

fun Context.sectionTitle(s: String): TextView =
    tv(s.uppercase(), 12f, Ui.MUTED, true).apply { letterSpacing = 0.06f }

fun Context.column(): LinearLayout =
    LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(8), dp(16), dp(24))
    }

fun Context.cardBox(padDp: Int = 16): LinearLayout =
    LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(Ui.CARD, 16, Ui.LINE, 1)
        setPadding(dp(padDp), dp(padDp), dp(padDp), dp(padDp))
    }

fun Context.button(label: String, filled: Boolean = true, onClick: () -> Unit): TextView =
    TextView(this).apply {
        text = label
        textSize = 15f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(if (filled) Color.WHITE else Ui.BLUE)
        gravity = Gravity.CENTER
        minHeight = dp(48)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = ripple(shape(if (filled) Ui.BLUE else Ui.BLUE_SOFT, 14), 14)
        setOnClickListener { onClick() }
    }

/** state: 0 — обычный, 1 — выбран, 2 — мягкий (в нём есть данные). */
fun Context.styleChip(v: TextView, state: Int) {
    val (bg, fg) = when (state) {
        1 -> Ui.BLUE to Color.WHITE
        2 -> Ui.BLUE_SOFT to Ui.BLUE
        else -> Ui.FIELD to Ui.TEXT
    }
    v.background = shape(bg, 18)
    v.setTextColor(fg)
}

fun Context.chip(label: String, onClick: () -> Unit): TextView =
    TextView(this).apply {
        text = label
        textSize = 14f
        setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER
        setPadding(dp(14), dp(9), dp(14), dp(9))
        layoutParams = lp(WRAP, WRAP, end = 6)
        setOnClickListener { onClick() }
        styleChip(this, 0)
    }

fun Context.input(placeholder: String, value: String = ""): EditText =
    EditText(this).apply {
        setText(value)
        hint = placeholder
        textSize = 15f
        setTextColor(Ui.TEXT)
        setHintTextColor(Ui.HINT)
        setSingleLine()
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        background = shape(Ui.FIELD, 12)
        setPadding(dp(14), dp(12), dp(14), dp(12))
    }

fun EditText.onChanged(block: (String) -> Unit) {
    addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        override fun afterTextChanged(s: Editable?) { block(s?.toString() ?: "") }
    })
}

/** Переключатель-«таблетка» из нескольких пунктов. */
fun Context.segmented(items: List<String>, selected: Int, onSelect: (Int) -> Unit): LinearLayout {
    val box = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        background = shape(Ui.SEGMENT, 12)
        setPadding(dp(3), dp(3), dp(3), dp(3))
    }
    val views = mutableListOf<TextView>()
    fun paint(sel: Int) {
        views.forEachIndexed { i, v ->
            val on = i == sel
            v.background = shape(if (on) Ui.BLUE else Color.TRANSPARENT, 10)
            v.setTextColor(if (on) Color.WHITE else Ui.TEXT)
        }
    }
    items.forEachIndexed { i, s ->
        val v = TextView(this).apply {
            text = s
            textSize = 14f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(8), dp(10), dp(8), dp(10))
            setOnClickListener { paint(i); onSelect(i) }
        }
        views += v
        box.addView(v, LinearLayout.LayoutParams(0, WRAP, 1f))
    }
    paint(selected)
    return box
}

/** Ряд цветных кружков; выбранный отмечен галочкой. */
fun Context.swatches(colors: List<Int>, current: () -> Int, onPick: (Int) -> Unit): View {
    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    val items = mutableListOf<Pair<TextView, Int>>()
    fun refresh() {
        items.forEach { (v, c) ->
            v.text = if (c == current()) "✓" else ""
            v.setTextColor(Ui.contrast(c))
        }
    }
    colors.forEach { c ->
        val v = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            background = GradientDrawable().apply {
                setShape(GradientDrawable.OVAL)
                setColor(c)
                setStroke(dp(1), Ui.LINE)
            }
            layoutParams = lp(dp(40), dp(40), top = 8, bottom = 2, end = 8)
            setOnClickListener { onPick(c); refresh() }
        }
        items += v to c
        row.addView(v)
    }
    refresh()
    return android.widget.HorizontalScrollView(this).apply {
        isHorizontalScrollBarEnabled = false
        addView(row)
    }
}

// ---------- каркас экрана ----------

fun Activity.screen(header: View?, content: View, bottom: View?): View {
    val root = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(Ui.BG)
    }
    if (header != null) root.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))
    val scroll = ScrollView(this).apply { addView(content) }
    root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
    if (bottom != null) root.addView(bottom, LinearLayout.LayoutParams(MATCH, WRAP))
    return root
}

/** Шапка для режима «добавление виджета на экран»: просто заголовок. */
fun Activity.titleHeader(title: String): View =
    tv(title, 20f, Ui.TEXT, true).apply { setPadding(dp(16), dp(16), dp(16), dp(8)) }

/** Шапка с кнопкой «назад» и переключателем между настройками виджетов. */
fun Activity.tabsHeader(current: Int, onBack: () -> Unit, onSwitch: (Int) -> Unit): View {
    val row = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(8), dp(8), dp(16), dp(8))
    }
    val back = tv("‹", 30f, Ui.TEXT).apply {
        gravity = Gravity.CENTER
        setOnClickListener { onBack() }
    }
    row.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
    row.addView(
        segmented(listOf("Неделя", "Расписание"), current) { if (it != current) onSwitch(it) },
        lp(w = 0, weight = 1f)
    )
    return row
}

/**
 * Шапка для режима «тап по виджету»: стрелка «назад», заголовок и кнопка «В меню»,
 * которая ведёт на главный экран с лентой виджетов.
 */
fun Activity.widgetHeader(title: String, onBack: () -> Unit, onMenu: () -> Unit): View {
    val row = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(8), dp(8), dp(16), dp(8))
    }
    val back = tv("‹", 30f, Ui.TEXT).apply {
        gravity = Gravity.CENTER
        setOnClickListener { onBack() }
    }
    row.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))

    val titleView = tv(title, 18f, Ui.TEXT, true).apply {
        maxLines = 1
        ellipsize = android.text.TextUtils.TruncateAt.END
    }
    row.addView(titleView, lp(w = 0, weight = 1f))

    val menu = tv("В меню", 14f, Ui.BLUE, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(14), dp(9), dp(14), dp(9))
        background = ripple(shape(Ui.BLUE_SOFT, 18), 18)
        setOnClickListener { onMenu() }
    }
    row.addView(menu, lp(WRAP, WRAP, start = 8))
    return row
}

fun Activity.bottomBar(label: String, onClick: () -> Unit): View {
    val box = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(Ui.CARD)
    }
    box.addView(View(this).apply { setBackgroundColor(Ui.LINE) }, LinearLayout.LayoutParams(MATCH, dp(1)))
    val pad = LinearLayout(this).apply { setPadding(dp(16), dp(10), dp(16), dp(10)) }
    pad.addView(button(label, true, onClick), LinearLayout.LayoutParams(MATCH, WRAP))
    box.addView(pad, LinearLayout.LayoutParams(MATCH, WRAP))
    return box
}

// ---------- навигация и ссылки ----------

/** 0 — настройки виджета «Неделя», 1 — настройки виджета «Расписание». */
fun Activity.switchTab(index: Int) {
    val target = if (index == 0) ConfigActivity::class.java else ScheduleActivity::class.java
    startActivity(Intent(this, target))
    finish()
    overridePendingTransition(0, 0)
}

/** Открывает главный экран (ленту виджетов) и закрывает текущий. */
fun Activity.openMain() {
    startActivity(
        Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
    )
    finish()
}

fun Activity.openUrl(url: String) {
    try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (e: Exception) {
        Toast.makeText(this, "Не удалось открыть ссылку", Toast.LENGTH_SHORT).show()
    }
}

fun weekRangeText(): String {
    val monday = WeekLogic.mondayOf(LocalDate.now())
    val f = DateTimeFormatter.ofPattern("d MMM", Locale.forLanguageTag("ru"))
    return "${f.format(monday)} – ${f.format(monday.plusDays(6))}"
}
