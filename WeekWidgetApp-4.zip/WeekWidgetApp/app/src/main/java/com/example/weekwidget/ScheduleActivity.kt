package com.example.weekwidget

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.time.LocalDate

/**
 * Редактор расписания.
 *  - пары вводятся строками: время (пикер) + предмет (с автодополнением);
 *  - «быстрый ввод» понимает строки вида «9 математика 305»;
 *  - «вставить списком» разбирает целый день, вставленный из заметок/мессенджера;
 *  - день можно скопировать в любые другие дни обеих недель.
 */
class ScheduleActivity : Activity() {

    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private val standalone: Boolean get() = widgetId == AppWidgetManager.INVALID_APPWIDGET_ID

    private val data = mutableMapOf<String, String>()
    private val rows = mutableListOf<Lesson>()
    private var history = listOf<String>()

    private var editingNum = false
    private var editingDow = 1
    private var currentIsNum = false
    private var bgColor = 0
    private var align = ALIGN_LEFT

    /** true — система добавляет виджет на экран (результат нужен лаунчеру); false — обычное открытие. */
    private val adding: Boolean get() = intent?.action == AppWidgetManager.ACTION_APPWIDGET_CONFIGURE

    private lateinit var rowsBox: LinearLayout
    private lateinit var editTitle: TextView
    private lateinit var quick: EditText
    private val dayChips = mutableListOf<TextView>()
    private val shortDays = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        widgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        setResult(RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))

        for (n in listOf(true, false)) for (d in 1..7) {
            data[ScheduleStore.key(n, d)] = ScheduleStore.getDay(this, n, d)
        }
        currentIsNum = ScheduleStore.isNumeratorToday(this)
        editingNum = currentIsNum
        editingDow = LocalDate.now().dayOfWeek.value
        bgColor = ScheduleStore.bg(this)
        align = ScheduleStore.align(this)
        rows.addAll(Lessons.fromText(data[ScheduleStore.key(editingNum, editingDow)] ?: ""))
        history = buildHistory()

        val col = column()

        // --- Какая неделя сейчас ---
        val c1 = cardBox()
        c1.addView(sectionTitle("Какая неделя сейчас"))
        c1.addView(tv(weekRangeText(), 14f, Ui.MUTED), lp(top = 2))
        c1.addView(
            segmented(listOf("Над чертой", "Под чертой"), if (currentIsNum) 0 else 1) {
                currentIsNum = it == 0
                updateTitle()
            },
            lp(top = 10)
        )
        col.addView(c1, lp())

        // --- Редактор ---
        val c2 = cardBox()
        c2.addView(sectionTitle("Расписание"))
        c2.addView(
            segmented(listOf("Над чертой", "Под чертой"), if (editingNum) 0 else 1) {
                switchTo(it == 0, editingDow)
            },
            lp(top = 10)
        )

        val dayRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        shortDays.forEachIndexed { i, name ->
            val c = chip(name) { switchTo(editingNum, i + 1) }
            dayChips += c
            dayRow.addView(c)
        }
        c2.addView(
            HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(dayRow)
            },
            lp(top = 10)
        )

        editTitle = tv("", 17f, Ui.TEXT, true)
        c2.addView(editTitle, lp(top = 14))

        // Быстрый ввод
        quick = input("Быстро: 9 математика 305").apply {
            imeOptions = EditorInfo.IME_ACTION_DONE
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setOnEditorActionListener { _, actionId, event ->
                val enter = event != null && event.keyCode == KeyEvent.KEYCODE_ENTER &&
                    event.action == KeyEvent.ACTION_DOWN
                if (actionId == EditorInfo.IME_ACTION_DONE || enter) {
                    addFromQuick()
                    true
                } else false
            }
        }
        val quickRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        quickRow.addView(quick, lp(w = 0, weight = 1f, end = 8))
        quickRow.addView(button("+") { addFromQuick() }, lp(w = dp(52)))
        c2.addView(quickRow, lp(top = 8))

        rowsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c2.addView(rowsBox, lp(top = 4))

        c2.addView(
            tv("Нажми на время, чтобы изменить. Долгое нажатие — убрать время.", 12f, Ui.HINT),
            lp(top = 8)
        )

        val btnRow1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btnRow1.addView(button("+ Пара", false) { addEmptyRow() }, lp(w = 0, weight = 1f, end = 8))
        btnRow1.addView(button("Вставить списком", false) { showPasteDialog() }, lp(w = 0, weight = 1.4f))
        c2.addView(btnRow1, lp(top = 12))

        val btnRow2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btnRow2.addView(button("Копировать день…", false) { showCopyDialog() }, lp(w = 0, weight = 1.4f, end = 8))
        btnRow2.addView(button("Очистить", false) { confirmClear() }, lp(w = 0, weight = 1f))
        c2.addView(btnRow2, lp(top = 8))

        col.addView(c2, lp(top = 12))

        // --- Оформление ---
        val c3 = cardBox()
        c3.addView(sectionTitle("Цвет виджета"))
        c3.addView(swatches(Ui.PALETTE, { bgColor }) { bgColor = it })
        c3.addView(sectionTitle("Выравнивание текста"), lp(top = 16))
        c3.addView(
            segmented(listOf("По левому краю", "По центру"), if (align == ALIGN_LEFT) 0 else 1) {
                align = if (it == 0) ALIGN_LEFT else ALIGN_CENTER
            },
            lp(top = 10)
        )
        c3.addView(
            tv(
                "Виджет подстраивает размер текста и состав под свой размер: " +
                    "растяни его пальцами — на большом размере покажется вся неделя.",
                12f, Ui.HINT
            ),
            lp(top = 8)
        )
        col.addView(c3, lp(top = 12))

        val header = when {
            standalone -> tabsHeader(1, onBack = { persist(); finish() }, onSwitch = { persist(); switchTab(it) })
            adding -> titleHeader("Виджет «Расписание»")
            else -> widgetHeader("Виджет «Расписание»", onBack = { persist(); finish() }, onMenu = { persist(); openMain() })
        }

        setContentView(screen(header, col, bottomBar("Сохранить") { saveAndClose() }))

        renderRows()
        refreshChips()
        updateTitle()
    }

    override fun onBackPressed() {
        if (!adding) persist()
        super.onBackPressed()
    }

    // ---------- данные ----------

    private fun commit() {
        data[ScheduleStore.key(editingNum, editingDow)] = Lessons.toText(rows)
    }

    private fun persist() {
        commit()
        ScheduleStore.save(this, data, WeekLogic.mondayOf(LocalDate.now()), currentIsNum, bgColor, align)
        ScheduleWidgetProvider.updateAll(this)
    }

    private fun saveAndClose() {
        persist()
        if (standalone) {
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
        } else {
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        }
        finish()
    }

    /** Все названия, которые уже встречались в расписании — для автодополнения. */
    private fun buildHistory(): List<String> {
        val set = linkedSetOf<String>()
        data.values.forEach { text ->
            Lessons.fromText(text).forEach { l ->
                if (l.title.isNotBlank()) {
                    set += l.title
                    set += Lessons.baseTitle(l.title)
                }
            }
        }
        return set.filter { it.isNotBlank() }
    }

    private fun switchTo(num: Boolean, dow: Int) {
        commit()
        editingNum = num
        editingDow = dow
        rows.clear()
        rows.addAll(Lessons.fromText(data[ScheduleStore.key(num, dow)] ?: ""))
        history = buildHistory()
        renderRows()
        refreshChips()
        updateTitle()
    }

    private fun updateTitle() {
        val week = if (editingNum) "над чертой" else "под чертой"
        val now = if (editingNum == currentIsNum) "  ·  эта неделя" else ""
        editTitle.text = "${DAY_NAMES[editingDow - 1]}, $week$now"
    }

    private fun refreshChips() {
        dayChips.forEachIndexed { i, c ->
            val has = !data[ScheduleStore.key(editingNum, i + 1)].isNullOrBlank() ||
                (i + 1 == editingDow && rows.isNotEmpty())
            styleChip(c, if (i + 1 == editingDow) 1 else if (has) 2 else 0)
        }
    }

    // ---------- список пар ----------

    private fun renderRows(focusIndex: Int = -1) {
        rowsBox.removeAllViews()
        if (rows.isEmpty()) {
            rowsBox.addView(
                tv("Пар нет. Введи первую выше или нажми «+ Пара».", 14f, Ui.MUTED),
                lp(top = 12, bottom = 4)
            )
        }
        rows.forEach { rowsBox.addView(buildRow(it), lp(top = 8)) }

        if (focusIndex in rows.indices) {
            val field = (rowsBox.getChildAt(focusIndex) as LinearLayout).getChildAt(1)
            field.requestFocus()
            field.post {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(field, InputMethodManager.SHOW_IMPLICIT)
            }
        }
    }

    private fun buildRow(l: Lesson): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val time = TextView(this).apply {
            text = l.time.ifBlank { "--:--" }
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(Ui.BLUE)
            background = ripple(shape(Ui.BLUE_SOFT, 12), 12)
            setPadding(dp(10), dp(12), dp(10), dp(12))
            minWidth = dp(72)
            setOnClickListener { pickTime(l) }
            setOnLongClickListener {
                l.time = ""
                sortRows()
                renderRows()
                true
            }
        }
        row.addView(time, lp(WRAP, WRAP, end = 8))

        val field = AutoCompleteTextView(this).apply {
            setText(l.title, false)
            hint = "Предмет, ауд."
            textSize = 15f
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.HINT)
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            threshold = 1
            setAdapter(ArrayAdapter(this@ScheduleActivity, android.R.layout.simple_dropdown_item_1line, history))
            background = shape(Ui.FIELD, 12)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            onChanged { l.title = it }
        }
        row.addView(field, lp(w = 0, weight = 1f))

        val del = tv("✕", 18f, Ui.MUTED).apply {
            gravity = Gravity.CENTER
            setOnClickListener {
                rows.remove(l)
                renderRows()
                refreshChips()
            }
        }
        row.addView(del, lp(w = dp(40), h = dp(40), start = 4))
        return row
    }

    private fun sortRows() {
        rows.sortBy { Lessons.sortKey(it.time) }
    }

    private fun pickTime(l: Lesson) {
        val idx = rows.indexOf(l)
        val prev = rows.take(idx).lastOrNull { it.time.isNotBlank() }?.time
        val (h, m) = Lessons.startOf(l.time) ?: Lessons.startOf(Lessons.nextSlot(prev))!!
        TimePickerDialog(
            this,
            TimePickerDialog.OnTimeSetListener { _, hh, mm ->
                l.time = String.format("%02d:%02d", hh, mm)
                sortRows()
                renderRows()
            },
            h, m, true
        ).show()
    }

    // ---------- добавление ----------

    private fun addEmptyRow() {
        val prev = rows.lastOrNull { it.time.isNotBlank() }?.time
        rows += Lesson(Lessons.nextSlot(prev), "")
        renderRows(focusIndex = rows.size - 1)
        refreshChips()
    }

    private fun addFromQuick() {
        val t = quick.text.toString()
        if (t.isBlank()) return
        addParsed(t, replace = false)
        quick.setText("")
    }

    /** Разбирает текст (одна пара на строку); пары без времени получают ближайший звонок. */
    private fun addParsed(text: String, replace: Boolean) {
        val parsed = Lessons.fromText(text)
        if (parsed.isEmpty()) return
        if (replace) rows.clear()
        var prev = rows.lastOrNull { it.time.isNotBlank() }?.time
        parsed.forEach {
            if (it.time.isBlank()) it.time = Lessons.nextSlot(prev)
            prev = it.time
        }
        rows.addAll(parsed)
        sortRows()
        renderRows()
        refreshChips()
    }

    private fun showPasteDialog() {
        val input = EditText(this).apply {
            minLines = 6
            gravity = Gravity.TOP or Gravity.START
            hint = "9:00 Математика 305\n10:40 Физика 112\n12:20 Английский"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        val wrap = FrameLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("Вставить списком")
            .setMessage("Одна пара на строку. Время и аудитории распознаются сами.")
            .setView(wrap)
            .setPositiveButton("Добавить") { _, _ -> addParsed(input.text.toString(), replace = false) }
            .setNeutralButton("Заменить день") { _, _ -> addParsed(input.text.toString(), replace = true) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    // ---------- копирование и очистка ----------

    private fun showCopyDialog() {
        val targets = mutableListOf<Pair<Boolean, Int>>()
        for (n in listOf(true, false)) for (d in 1..7) {
            if (!(n == editingNum && d == editingDow)) targets += n to d
        }
        val names = targets
            .map { "${shortDays[it.second - 1]} · ${if (it.first) "над чертой" else "под чертой"}" }
            .toTypedArray()
        val checked = BooleanArray(targets.size)

        AlertDialog.Builder(this)
            .setTitle("Скопировать «${shortDays[editingDow - 1]}» в:")
            .setMultiChoiceItems(names, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Копировать") { _, _ ->
                commit()
                val text = Lessons.toText(rows)
                var count = 0
                targets.forEachIndexed { i, (n, d) ->
                    if (checked[i]) {
                        data[ScheduleStore.key(n, d)] = text
                        count++
                    }
                }
                history = buildHistory()
                refreshChips()
                if (count > 0) Toast.makeText(this, "Скопировано: $count", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun confirmClear() {
        if (rows.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("Очистить день?")
            .setMessage("${DAY_NAMES[editingDow - 1]}, ${if (editingNum) "над чертой" else "под чертой"}")
            .setPositiveButton("Очистить") { _, _ ->
                rows.clear()
                renderRows()
                refreshChips()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }
}
