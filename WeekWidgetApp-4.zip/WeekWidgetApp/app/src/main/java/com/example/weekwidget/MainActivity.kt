package com.example.weekwidget

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import java.time.LocalDate

/**
 * Главный экран: лента (карусель) виджетов. Тап по карточке открывает настройки виджета,
 * а внутри настроек можно переключаться между виджетами верхним переключателем.
 */
class MainActivity : Activity() {

    private class Spec(val title: String, val desc: String)

    private val specs = listOf(
        Spec("Неделя", "Показывает, какая сейчас неделя: над чертой или под чертой"),
        Spec("Расписание", "Пары на сегодня с учётом чётности недели"),
    )

    private val previews = arrayOfNulls<FrameLayout>(2)
    private val dots = mutableListOf<View>()
    private lateinit var scroller: HorizontalScrollView
    private var step = 1
    private var touching = false
    private val handler = Handler(Looper.getMainLooper())
    private val snap = Runnable { snapNow() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = column()

        // Подпись автора — в самом верху.
        val credit = tv(Ui.CREDIT, 12f, Ui.BLUE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(6), dp(14), dp(6))
            background = shape(Ui.BLUE_SOFT, 20)
        }
        col.addView(credit, LinearLayout.LayoutParams(WRAP, WRAP).apply { gravity = Gravity.CENTER_HORIZONTAL })

        col.addView(tv("Мои виджеты", 30f, Ui.TEXT, true), lp(top = 16))
        col.addView(tv("Выбери виджет и настрой его под себя", 15f, Ui.MUTED), lp(top = 2))

        // --- Карусель ---
        val inner = resources.displayMetrics.widthPixels - dp(32)
        val cardW = (inner * 0.84f).toInt()
        val gap = dp(12)
        step = cardW + gap

        val track = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            // Запас справа, чтобы последняя карточка тоже вставала ровно по левому краю.
            setPadding(0, 0, inner - cardW, 0)
        }
        specs.forEachIndexed { i, spec ->
            val params = LinearLayout.LayoutParams(cardW, WRAP)
            if (i < specs.size - 1) params.rightMargin = gap
            track.addView(buildCard(i, spec), params)
        }

        scroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(track)
            setOnScrollChangeListener { _, x, _, _, _ ->
                updateDots(x)
                if (!touching) {
                    handler.removeCallbacks(snap)
                    handler.postDelayed(snap, 100)
                }
            }
            setOnTouchListener { _, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        touching = true
                        handler.removeCallbacks(snap)
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        touching = false
                        handler.removeCallbacks(snap)
                        handler.postDelayed(snap, 120)
                    }
                }
                false
            }
        }
        col.addView(scroller, lp(top = 16))

        // Точки-индикаторы
        val dotsRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        specs.forEach { _ ->
            val d = View(this)
            dots += d
            dotsRow.addView(d, lp(dp(8), dp(8), start = 4, end = 4))
        }
        col.addView(dotsRow, lp(top = 12))
        updateDots(0)

        // --- Как добавить ---
        val tip = cardBox()
        tip.addView(tv("Как добавить на главный экран", 15f, Ui.TEXT, true))
        tip.addView(
            tv(
                "Удерживай пустое место на главном экране → «Виджеты» → «Виджет недели». " +
                    "Там два виджета: «Неделя» и «Расписание».",
                14f, Ui.MUTED
            ),
            lp(top = 4)
        )
        col.addView(tip, lp(top = 20))

        // --- Telegram ---
        col.addView(buildTelegramCard(), lp(top = 12))

        col.addView(
            tv("Версия ${versionName()}", 12f, Ui.HINT).apply { gravity = Gravity.CENTER },
            lp(top = 16)
        )

        setContentView(screen(null, col, null))
    }

    override fun onResume() {
        super.onResume()
        fillWeekPreview()
        fillSchedulePreview()
    }

    // ---------- карточки ----------

    private fun buildCard(i: Int, spec: Spec): View {
        val box = cardBox(12)
        val preview = FrameLayout(this)
        previews[i] = preview
        box.addView(preview, lp(h = dp(150)))
        box.addView(tv(spec.title, 18f, Ui.TEXT, true), lp(top = 12))
        box.addView(tv(spec.desc, 13f, Ui.MUTED), lp(top = 2))
        box.addView(button("Настроить") { open(i) }, lp(top = 12))
        box.setOnClickListener { open(i) }
        return box
    }

    private fun open(i: Int) {
        val target = if (i == 0) ConfigActivity::class.java else ScheduleActivity::class.java
        startActivity(Intent(this, target))
    }

    private fun fillWeekPreview() {
        val box = previews[0] ?: return
        val cfg = ConfigStore.loadForUi(this)
        val num = cfg.isNumerator()
        val bg = if (num) cfg.numColor else cfg.denColor
        val fg = Ui.contrast(bg)

        box.removeAllViews()
        box.background = shape(bg, 16)
        val left = cfg.align == ALIGN_LEFT
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = if (left) Gravity.CENTER_VERTICAL or Gravity.START else Gravity.CENTER
            setPadding(if (left) dp(16) else 0, 0, 0, 0)
        }
        inner.addView(tv("Сейчас неделя", 12f, fg))
        inner.addView(tv(if (num) cfg.numLabel else cfg.denLabel, 26f, fg, true))
        if (cfg.showDates) inner.addView(tv(weekRangeText(), 13f, fg))
        box.addView(inner, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun fillSchedulePreview() {
        val box = previews[1] ?: return
        val bg = ScheduleStore.bg(this)
        val fg = Ui.contrast(bg)
        val num = ScheduleStore.isNumeratorToday(this)
        val dow = LocalDate.now().dayOfWeek.value
        val lines = ScheduleStore.getDay(this, num, dow)
            .lines().map { it.trim() }.filter { it.isNotEmpty() }

        box.removeAllViews()
        box.background = shape(bg, 16)
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        inner.addView(tv("${DAY_NAMES[dow - 1]} · ${if (num) "над чертой" else "под чертой"}", 14f, fg, true))
        val body = if (lines.isEmpty()) "Занятий нет" else lines.take(5).joinToString("\n") +
            if (lines.size > 5) "\n…" else ""
        inner.addView(tv(body, 13f, fg), lp(top = 6))
        box.addView(inner, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun buildTelegramCard(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = ripple(shape(Ui.CARD, 16, Ui.LINE, 1), 16)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setOnClickListener { openUrl(Ui.TELEGRAM_URL) }
        }
        val icon = ImageView(this).apply {
            setImageResource(R.drawable.ic_send)
            setColorFilter(Color.WHITE)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = oval(Ui.BLUE)
        }
        row.addView(icon, LinearLayout.LayoutParams(dp(44), dp(44)))

        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(tv("Наш Telegram", 16f, Ui.TEXT, true))
        texts.addView(tv("Новости, идеи и обратная связь", 13f, Ui.MUTED), lp(top = 1))
        row.addView(texts, lp(w = 0, weight = 1f, start = 14))

        row.addView(tv("›", 26f, Ui.MUTED))
        return row
    }

    // ---------- прокрутка ленты ----------

    private fun indexFor(x: Int): Int = ((x + step / 2) / step).coerceIn(0, specs.size - 1)

    private fun snapNow() {
        scroller.smoothScrollTo(indexFor(scroller.scrollX) * step, 0)
    }

    private fun updateDots(x: Int) {
        val cur = indexFor(x)
        dots.forEachIndexed { i, d -> d.background = oval(if (i == cur) Ui.BLUE else Ui.LINE) }
    }

    private fun versionName(): String =
        try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }

    override fun onDestroy() {
        handler.removeCallbacks(snap)
        super.onDestroy()
    }

}
